# T6.0 TAP input-lineage audit — decision rules

**Layer**: audit decision rule, committed **before the audit is run and before
any lineage measurement exists**. Written in response to the fifth internal
review §3.1 and instruction `P5R-L` §0, which designate this a submission
blocker.

**Zero-artifact attestation (repository state at the commit that introduces
this file)**: `results/T6_lineage/` does not exist;
`experiments/tap_lineage_audit.py` does not exist;
`data_lineage_audit.json` and `tap_input_provenance.json` do not exist
anywhere in the tree. No lineage digest, no masked-coordinate comparison and
no verdict of any kind has been computed. The rules below are therefore fixed
before their outcome can be known, and the outcome is whatever they return.

---

## 0. The question this audit answers

The manuscript states that `TAP_0`, the prespecified training-free
comparator, is computed **once on the initial statistical completion — the
same table the first training round would see**, and that under the corrected
benchmark **no imputer sees the complete table**.

The rule document `docs/T53_tap_family_rules.md` states that the baseline
family variants are computed from `data/derived_shuffled/{ds}_complete.csv`,
described there as *"the same input the archived TAP used"*.

If `{ds}_complete.csv` is the pre-mask benchmark table, those two statements
cannot both be true of the same object, and the second would mean a
comparator was fed the values the other side had to predict.

**This audit decides which is the case, by measurement, for every consumer.**

## 1. Definitions (fixed here)

- **G(ds)** — *ground-truth table*: the benchmark table for dataset `ds`
  **before any mask is applied**. Identified as the table that the mask
  generator reads as its input.
- **M(ds, mech, rate)** — *mask*: the boolean coordinate set recorded in
  `data/masks/clinical_v1_shuffled/{ds}/{ds}_{mech}_{rate}per_mask.npy`,
  with its companion `_meta.json`.
- **X_masked(ds, mech, rate)** — *masked table*: the table with the masked
  coordinates removed, i.e.
  `data/masks/clinical_v1_shuffled/{ds}/{ds}_{mech}_{rate}per.csv`.
- **F(ds, mech, rate)** — *prespecified initial completion*: the table
  obtained from `X_masked` by applying the initial statistical completion
  rule the imputer uses at round 1, computed by executing that code path,
  not by re-deriving it by hand. The rule's identity (which statistic, per
  column, estimated on what) is itself an audit output (item A4 below).
- A **consumer** is any code path that reads a feature table in order to
  produce an archived audit artifact. The consumers in scope are:
  1. `SNI round 1` — the host's first training round;
  2. `archived TAP_0` — the comparator whose readout enters the faithfulness,
     recovery and leakage axes;
  3. each of the five T5.3 baseline-family variants
     (uniform, random x20, abs-Spearman, normalized MI, observed-only).

## 2. Audit A — file identity

**A1.** Locate every script that writes a file matching `*_complete.csv`.
Record the script, its input, and whether it runs **before** or **after** the
masking step. If more than one producer exists, record all of them.

**A2.** Record `sha256` and shape for:
 (i) `data/derived_shuffled/{ds}_complete.csv`;
 (ii) the table `SNI round 1` actually consumed;
 (iii) the table the `archived TAP_0` actually consumed;
 (iv) `X_masked` and `G` for every (ds, mech, rate) in scope.

**A3.** Where a consumed table is not an on-disk artifact but an in-memory
frame, it is **reconstructed** by executing the same deterministic code path
on the archived inputs under the archived configuration and seed. A
reconstructed table is hashed over a canonical serialisation — column names,
dtypes, then float64 little-endian bytes in C order, NaN as its canonical bit
pattern — and is labelled `reconstructed: true` in the artifact. A
reconstruction is evidence about the code path, not about the historical
process memory, and is reported as such.

**A4.** Record the initial-completion rule verbatim from source: which
statistic per column type, whether it is estimated on the training block
only, and whether the downstream target column can enter it.

**A5.** Every byte-difference between (i), (ii) and (iii) is itemised: same
shape? same column order? same dtypes? differing cell count? Differences are
explained, not summarised.

## 3. Audit B — the decisive test (masked-coordinate value check)

For each dataset and each mask in scope, and for each candidate table `X`
among {`{ds}_complete.csv`, the SNI round-1 input, the archived TAP_0 input,
each family variant's input}:

Restrict to the masked coordinates `M`. For every masked cell `(i, j)`
classify it into exactly one of:

- `equals_fill_only` — `X[i,j] == F[i,j]` and `X[i,j] != G[i,j]`;
- `equals_truth_only` — `X[i,j] == G[i,j]` and `X[i,j] != F[i,j]`;
- `equals_both` — `X[i,j] == F[i,j] == G[i,j]` (a coincidence of the fill
  rule with the withheld value; expected for mode-filled categoricals and
  possible for continuous columns);
- `equals_neither` — anything else;
- `missing` — `X[i,j]` is NaN (the masked table itself, and any consumer
  that legitimately reads it).

Comparison of floats is **exact** (`==` on the stored float64), because a
correctly-filled cell carries the fill value bit-for-bit and a leaked cell
carries the withheld value bit-for-bit; no tolerance is introduced, and any
near-miss lands in `equals_neither` where it is visible.

### The verdict rule (fixed here)

A candidate table `X` is:

- **CLEAN-COMPLETION** iff `equals_truth_only == 0` **and**
  `equals_neither == 0` **and** `missing == 0` — i.e. every masked cell
  carries the prespecified fill value (whether or not that value happens to
  coincide with the truth).
- **CLEAN-MASKED** iff `missing == count(M)` — i.e. the candidate is the
  masked table itself, with the withheld cells still absent. This is the only
  admissible state for the observed-only family variant.
- **LEAKING** iff `equals_truth_only > 0` — at least one masked cell carries
  the withheld value where the fill rule would have produced something else.
- **INDETERMINATE** otherwise (e.g. `equals_neither > 0`), which is reported
  as such and is **not** treated as clean.

`equals_both` is recorded and reported for interpretability but **cannot on
its own** make a table LEAKING or CLEAN — it is the coincidence class.

Up to five concrete example coordinates per class per (dataset, mask,
candidate) — with the three values `X`, `F`, `G` — are written into the
evidence artifact, so a reader can check the classification by hand.

## 4. Audit C — the host side

The SNI round-1 input is subjected to Audit A and Audit B exactly as above.
The assertion under test is `SNI_round1_input == F` (Audit A, byte-level) and
`SNI round-1 input is CLEAN-COMPLETION` (Audit B). Both must hold.

## 5. Audit D — family fairness

For each of the five T5.3 variants, record the exact source expression that
selects its input table, and classify that input under Audit B. The
prespecified expectation, from `T53_tap_family_rules.md` itself, is:

- observed-only ⇒ **CLEAN-MASKED** (it is defined as pairwise-complete
  association on the masked table);
- the other four ⇒ the *same* fair input as the archived `TAP_0`, hence
  **CLEAN-COMPLETION** and byte-identical to the archived TAP_0 input.

A variant fed a table that is LEAKING, or fed a different table from the
archived `TAP_0` while the rules say it is the same, is a finding.

## 6. Decision tree (mechanical; evaluated by the script, not by hand)

The instruction's tree is binary. It is refined here into three outcomes
**before any measurement exists**, because a defect confined to the T5.3
sensitivity family has a different consequence from a defect in the primary
comparison chain, and collapsing them would either overstate or understate
what was found. The refinement is declared here so that it cannot be chosen
after seeing the numbers.

- **PASS** — every consumer in scope is CLEAN-COMPLETION, except the
  observed-only variant which is CLEAN-MASKED; and the archived TAP_0 input
  is byte-identical to the SNI round-1 input.
  ⇒ The matter is one of evidence and naming. Actions: rename or explicitly
  define `*_complete.csv` throughout as the *initial-completion working
  table* if that is what it is, or correct `T53` if the family read a
  different table than its text says; add a data-lineage table/figure to the
  ESM (raw table → mask → initial completion → each consumer); ship
  `data_lineage_audit.json` in the package evidence; add a dated addendum to
  `T53` clarifying the path semantics (rule body unchanged). Then proceed to
  the rest of the instruction.

- **SCOPED-DEFECT** — every consumer on the **primary chain** (SNI round 1
  and archived TAP_0) is clean, but at least one T5.3 family variant is
  LEAKING or INDETERMINATE.
  ⇒ The primary results stand; the T5.3 family readouts become
  **recompute-pending** and may not be reported as valid. Report to the first
  author and to Chat before any packaging, state the scope precisely, and
  await adjudication. Do not begin a recomputation unbidden.

- **FAIL** — any primary-chain consumer is LEAKING or INDETERMINATE.
  ⇒ Stop. Report to the first author and to Chat immediately. All
  TAP-dependent results enter recompute-pending. Produce the affected-result
  inventory and a costed recomputation estimate for adjudication. **Do not
  begin recomputation, and do not package anything.**

## 7. Outputs (fixed here)

- `experiments/tap_lineage_audit.py` — the audit, with `--selftest` that
  proves the classifier on synthetic fixtures in which a leak is planted and
  must be caught, and a clean case that must pass.
- `results/T6_lineage/data_lineage_audit.json` — the machine-readable audit:
  per dataset, per mask, per candidate, the five counts, the verdict, the
  example coordinates, every sha256, and the top-level decision-tree outcome.
- `results/T6_lineage/tap_input_provenance.json` — the per-dataset,
  per-condition provenance record the fifth review asks for by name
  (`complete_ground_truth_path`/`sha256`, `masked_input_path`/`sha256`,
  `initial_completion_path`/`sha256`, `TAP0_input_path`/`sha256`,
  `SNI_round1_input_path`/`sha256`, `mask_path`/`sha256`, and the
  masked-coordinate-only digest of each table).

Both artifacts are generated; neither is hand-edited. The prose that cites
them cites fields.

## 8. What this audit cannot establish

It establishes what the **code paths on disk today** consume, and what the
**archived artifacts on disk today** contain. It cannot establish what a
process held in memory in July 2026 beyond what those artifacts and that code
determine. Where a table is reconstructed rather than read, the artifact says
so. This limit is stated in the audit output and in whatever prose cites it.
