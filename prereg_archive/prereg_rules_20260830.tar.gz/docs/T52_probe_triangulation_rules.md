# T5.2 probe triangulation rules (P5R SS2; internal review SS4.2)

**Timing disclosure**: written after the single-probe faithfulness results
were known -- the single-probe dependence is the defect under repair.
Committed BEFORE any probe-2 measurement exists: at commit time no group-
permutation delta, no group-level correlation, and no triangulated verdict
exists anywhere in the repository (attested in the commit body). All free
parameters are fixed here.

## Probes

- **Probe 1 (existing)**: per-source single-column permutation ablation
  (T3.2's A matrices, unchanged). Its prose is downgraded everywhere from
  "the model's behaviour" to "sensitivity to this permutation probe".
- **Probe 2 (this document)**: **group/conditional permutation** on the
  archived models -- correlated source clusters are permuted jointly, so
  the readout is not distorted by within-cluster substitution, the known
  failure mode of probe 1 on correlated tables. Zero retraining: models
  are reloaded from the archived `models_{tag}.pt` files; the inference
  path is byte-for-byte `faithfulness.run_one`'s (same encoder,
  standardization on target-observed rows, eval + no_grad, y-scaler
  inverse; the std-normalised error convention).
- **Probe 3 (priced, not run)**: predictor-level LOCO or
  distribution-preserving masking; feasibility and machine-hours go to
  the receipt for adjudication.

## Probe-2 design (all fixed here)

1. **Clusters**: per table, connected components of the graph on features
   with edges where the pooled type-aware |correlation| exceeds
   **0.8** -- the SAME matrix and threshold the pre-registered T3.2-R1
   redundancy precheck fixed (`C_pooled_corr_{ds}.csv`). Features in no
   component are singleton groups; the groups partition the full source
   set. Sensitivity: the partition is recomputed at thresholds 0.6 and
   0.7 and the whole readout re-run per threshold, reported as a curve;
   0.8 is the headline (inherited threshold, not tuned here).
2. **Scope**: every archived SNI-variant host of the faithfulness
   families (both tables, all seeds present on disk when the harness
   runs; the count is recorded). NoPrior hosts are the robustness mirror,
   same machinery.
3. **Measurement**: for target f and group G (f removed from its group;
   a group containing only f is skipped), draw ONE row permutation per
   repetition and apply it to ALL member columns of G jointly in the
   standardized encoded matrix; B[f, G] = mean over 5 repetitions of
   (pooled std-normalised error after permutation - baseline error),
   exactly probe 1's convention lifted to sets. RNG, pre-registered and
   disjoint from every existing stream:
   `np.random.default_rng(70_000 + 1_000*seed + 100*f_index + 20*g_index + r)`,
   r in 0..4, f_index = position in the table's feature order, g_index =
   the group's position in the partition sorted by first-member column
   order.
4. **Object group scores**: for each audit object M (SNI-D, TAP, and the
   MF readouts where their matrices exist), M_group[f, G] = **mean** of
   M[f, j] over members j of G (primary; the member **sum** is reported
   as a sensitivity column). Same treatment for every object -- one
   ruler.
5. **Per-cell readout**: rho_group = Spearman(B[f, .], M_group[f, .])
   over the partition cells, per (table, seed, target); paired
   Delta rho_group (D - TAP) enters the T5.1 cluster-robust machinery
   unchanged (seed blocks, M1 mean-of-seed-medians + M2 hierarchical
   bootstrap, the branch mapping, the disclosed enumeration floor at the
   realized seed count).

## Triangulated reading (fixed before any probe-2 number)

The behavioural-axis sentence may call D "not faithful to the host's
behaviour" ONLY if D fails to exceed TAP on **both** independent
behavioural readouts (probe 1 and probe 2), each under its cluster-robust
branch. If the probes disagree, the text reports the disagreement as the
finding and no unqualified faithfulness verdict is written. Reliability
qualifiers reported alongside either way: permutation-count sensitivity
(5 vs 10 repetitions on one seed per table), cluster-threshold
sensitivity (0.6 / 0.7 / 0.8), and the probe-1/probe-2 agreement per
cell. This rule qualifies wording; it gates no pre-registered verdict
retroactively.

## Outputs

`results/T5_probe2/probe2_cells.csv` (per table x seed x target x
threshold: rho_group per object, n_groups, n_singletons) +
`probe2_summary.json` (family-level M1/M2 per table and threshold,
branch, agreement table). Prose cites fields; no hand-copied number.

---

**Addendum (2026-08-28, second internal review SS4; interpretation
downgrade, rule body unchanged)**: *[Date corrected 2026-08-29: this addendum was first written with the date 2026-08-31, which no clock in this project ever showed. Its true authoring date is the date of the commit that introduced it, `9a00b02`, 2026-08-28; the commit history, not this line, is the evidence. The rule body is unchanged by the correction.]* the second review established that at
the pre-registered headline threshold both tables' partitions are all
singletons, so probe 2 there is a fresh-draw near-replication of probe 1
rather than a mechanistically independent intervention, and the joint
group permutation supports the deficit on eICU only (MIMIC
inconclusive). The reading of this document's "triangulated" clause is
accordingly downgraded: probe 2 is reported as a **repeat-draw
replication plus group-permutation sensitivity analysis** sharing the
unconditional-permutation assumption, not as a second independent
behavioural readout, and the faithfulness conclusion is stated as weak
concordance with the prespecified permutation-based behavioural
references used in this study. Mechanistically different probes
(conditional permutation, distribution-preserving masking, LOCO) remain
available extensions, not undertaken this round.
