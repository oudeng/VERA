# T5.3 TAP baseline-family rules (P5R-H SS7.1; third review P1-1)

**Layer**: prospectively specified sensitivity analysis -- committed
before any family matrix or family readout exists (attested in the
commit body), after the primary faithfulness results were known. The
purpose is contextual placement of the attention matrix and TAP within
a family of training-free references; no committed verdict is gated on
these readouts, and no wording of the primary analyses changes by rule.

## Scope

With-prior faithfulness axis only: both tables (MIMIC, eICU), every
archived with-prior seed whose ablation matrix `A_{ds}_seed{s}_cpu_t2.csv`
is on disk when the runner starts (expected 15 per table; the realized
count is recorded). Zero retraining: every variant is computed from
frozen inputs -- the complete table (`data/derived_shuffled/{ds}_complete.csv`,
the same input the archived TAP used) or, for the observed-only
variant, the frozen MAR@30 masked table.

## Variants (all free parameters fixed here)

1. **uniform**: constant off-diagonal matrix. Expected degenerate by
   construction -- a constant row induces no ranking; reported as such
   (Spearman with a constant vector is undefined), serving as the
   information-free anchor.
2. **random**: 20 replicates; replicate r for dataset index d
   (MIMIC=0, eICU=1) uses `np.random.default_rng(90_000 + 1_000*d + r)`,
   i.i.d. U(0,1) per off-diagonal entry, diagonal zero. The empirical
   floor band = the across-replicate distribution.
3. **abs-spearman**: the TAP recipe with Spearman in place of Pearson --
   identical one-hot encoding, identical NaN handling, identical
   type-aware block pooling and row treatment (no row normalisation in
   the readout path, matching the archived P readout).
4. **mutual-information** (the nonlinear member): per feature pair,
   `sklearn.metrics.normalized_mutual_info_score` on discretized
   columns -- continuous columns cut into 8 quantile bins
   (`pandas.qcut`, duplicates dropped), categorical columns native;
   symmetric; diagonal excluded. Discretization fixed here, not tuned.
5. **observed-only TAP** (the B1-case analog: association computable
   with no completion at all): pairwise-complete Pearson on the frozen
   MAR@30 masked table (`data/masks/clinical_v1_shuffled/{ds}/{ds}_MAR_30per.csv`),
   same encoding and pooling as TAP; entries with fewer than 30
   pairwise-complete rows are set to zero and counted.

## Readout (one ruler)

For each (variant, table, seed, target f): sources = features minus f;
rho = Spearman(variant row over sources, archived A row over sources) --
byte-for-byte the archived probe-1 full-scope convention. Family
statistics per variant and table: T = mean of seed-level median
Delta-rho(variant - TAP) with exact enumeration under seed-block
sign-exchangeability and the seed-only bootstrap CI -- the manuscript's
unified estimand -- reported descriptively (sensitivity layer, no
verdict). The absolute rho level distribution per variant is reported
alongside (median over targets per seed, then the seed median).
The uniform variant reports its degeneracy; the random variant reports
the floor band (min / median / max of its 20 replicate T values and
levels).

## Outputs

`results/T5_family/tapfam_cells.csv` (per variant x table x seed x
target: rho) + `results/T5_family/tapfam_summary.json` (family
statistics as above + realized seed counts + parameters echoed). Prose
cites fields; no hand-copied number.
