# T5.3 input correction — rules

**Layer**: defect-correction rule, committed **before the corrected artifacts
exist**. Written after the T6.0 lineage audit
(`docs/T60_tap_lineage_audit_rules.md`, run recorded in
`results/T6_lineage/data_lineage_audit.json`) returned SCOPED-DEFECT, and
after the first author adjudicated on 2026-08-29 that the family be
recomputed rather than withdrawn or annotated.

**Zero-artifact attestation (repository state at the commit introducing this
file)**: no corrected family artifact exists. `results/T5_family/` contains
exactly the two contaminated artifacts and nothing else —
`tapfam_cells.csv` (md5 `32fa97c8af8681c8af9e8336956493dd`) and
`tapfam_summary.json` (md5 `1908ea372045292637117e21bb2df9c3`);
`results/T5_family/superseded_20260829_wrong_input/` does not exist; no
recomputation has been run and no corrected number has been seen. The rules
below are therefore fixed before their outcome can be known.

---

## 1. What was wrong

`experiments/t53_tap_family.py` fed its `abs_spearman` and
`mutual_information` variants `data/derived_shuffled/{ds}_complete.csv` —
the **pre-mask ground-truth benchmark table**. On every masked coordinate
(10,260 MIMIC, 5,148 eICU) those inputs carried the withheld value.

`docs/T53_tap_family_rules.md` describes that file as *"the same input the
archived TAP used"*. **That clause is false.** The archived TAP_0 was
computed on the MICE initial completion of the masked table, proven at the
artifact level: the archived matrix reproduces from the initial completion to
1.5e-15 (MIMIC) / 3.1e-13 (eICU) and from the pre-mask table only to 0.110 /
0.092.

The comparison was therefore asymmetric and **favoured the two variants**,
which is the direction that makes this a correction rather than a
convenience.

## 2. What changes, and what does not

**Changes — exactly one thing:** the table those two variants are computed
on. They are now computed on the same initial completion the archived TAP_0
used, obtained by the same code path
(`SNIImputer(max_iters=0).impute(X_missing=missing, X_complete=None,
mask_df=mask_df)`), for the same seed the archived TAP_0 used
(`ARCHIVED_TAP_SEED = 1`).

**Does not change:** every variant definition in
`docs/T53_tap_family_rules.md` §Variants — the encoding, the type-aware block
pooling, the Spearman substitution, the 8-bin quantile discretisation for
mutual information, the 20 random replicates and their RNG seeds, the
uniform variant's degeneracy, the `observed_only_tap` variant (which reads
the frozen masked table and is already correct), the readout convention, the
unified T estimand, the exact enumeration, the seed-only bootstrap, and the
sensitivity-layer status with no verdict gated on it.

## 3. This is a defect correction, not a favourable re-run

Fixed here, before any corrected number exists:

- The corrected numbers are reported **whichever direction they move**. If
  the correction reverses, weakens or strengthens the family reading, that is
  what the ESM and the response letter will say.
- There is **one** corrected run. No variant of the fix is tried and
  compared; no seed, no discretisation and no threshold is revisited.
- The contaminated artifacts are **archived, not overwritten**:
  `results/T5_family/tapfam_cells.csv` and `tapfam_summary.json` are copied
  verbatim to `results/T5_family/superseded_20260829_wrong_input/` before the
  corrected run writes, and their md5s are recorded above and in the
  correction record.
- The **difference between the two sets of numbers is itself reported** —
  per variant, per table: the old T, the new T, and the change. A correction
  that is not shown beside what it replaced is not auditable.

## 4. Proof obligation: the path change does not count as proof

Changing the input expression is not evidence that the input changed. The
corrected inputs are subjected to **the same decisive test** the audit used
(T6.0 §3): the masked-coordinate value check, exact comparison, five classes,
with the verdict rule unchanged.

**Acceptance criterion, fixed here:** both corrected variant inputs must
classify as **CLEAN-COMPLETION** on both datasets — every masked cell equal
to the initial-completion value, zero cells equal to the withheld truth —
and their masked-coordinate digest must equal the archived TAP_0 input's.
`observed_only_tap` must remain **CLEAN-MASKED**. If any of these fails, the
correction is not accepted and the failure is reported.

## 5. Consumer census (first author's condition 4)

A census of every code path that reads a ground-truth table
(`data/derived/*_complete.csv`, `data/derived_shuffled/*_complete.csv`) is
produced as a machine-readable artifact and classified into:

- **L1** — read only to build the masked table (`complete[feats].mask(...)`);
- **L2** — read to obtain the withheld true values for **scoring** (RMSE,
  NRMSE, the ablation matrix's error target). Legitimate: that is what a
  benchmark is. Enumerated, not waved through;
- **L3** — read to construct an injected leakage proxy. Legitimate: that is
  the leakage experiment's premise;
- **L4** — read for a design pre-check applied symmetrically to every object
  (the T3.2-R1 redundancy pre-check). Reported separately, with whether its
  prospective specification says so;
- **X** — read to compute an audit object, comparator or reported statistic
  that competes with an object computed from the masked or completed table.
  **This is the defect shape.**

The census must find **zero** remaining X after the correction. Any UNCLEAR
entry is reported as unclear and adjudicated, not silently classified.

## 6. Naming remediation

The defect was caused by the name. `{ds}_complete.csv` means *complete-case*
(rows with no natural missingness) and is the **pre-mask ground truth**; the
manuscript elsewhere uses "complete table" for exactly that, which is why the
T53 sentence read as if it named the fair input. Remediation, all three:

1. `data/derived_shuffled/README.md` defines the table, its provenance and
   what it is not, in one place;
2. `common/tables.py` provides named accessors —
   `ground_truth_table()`, `masked_table()`, `initial_completion()` — so that
   new code says at the call site which table it means, and the literal path
   stops being the interface;
3. the ESM gains a **data-lineage table**: raw source → mask → masked table →
   initial completion → each consumer, so a reader can see the chain without
   reading the code.

## 7. Outputs

- `results/T5_family/superseded_20260829_wrong_input/` — the contaminated
  artifacts, verbatim, with a `README.md` stating why they are kept;
- `results/T5_family/tapfam_cells.csv`, `tapfam_summary.json` — corrected;
- `results/T6_lineage/t53_correction_record.json` — old vs new T per variant
  per table, the masked-coordinate re-verification, and the census result;
- `results/T6_lineage/consumer_census.json` — §5.

## 8. What the response letter and the ESM must say

Both must state, in their own words but without softening:

- the central comparison (D vs TAP_0 on faithfulness, recovery, leakage) is
  **unaffected**, and why — the archived TAP_0 reproduces from the initial
  completion and not from the pre-mask table;
- the defect was **real**, was **confined to the ESM's baseline-family
  sensitivity analysis**, and **favoured the variants** it affected;
- the family numbers now reported are the corrected ones, and the previous
  ones were computed on the wrong input.
