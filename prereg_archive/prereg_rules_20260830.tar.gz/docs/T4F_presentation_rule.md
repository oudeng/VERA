# T4F presentation rule — permutation-on-SNI (pre-registered)

**Status: committed before any permutation-on-SNI number existed.** At commit
time the pilot's synthetic cells have no stored SNI models (verified by
listing), no synthetic ablation matrix has been computed, and no cross-seed
stability of the real-table A matrices has been calculated. This file fixes
how the comparator is REPORTED, whichever way its numbers fall — the same
discipline as the pilot rule, 6030500 and 00a7984, and it matters more here
than there: this is a comparator we proposed ourselves and that could favour
us, so its presentation must be locked before its results exist.

## What it is

Permutation importance computed on SNI itself: T3.2's ablation machinery
(row-wise permutation of the standardized input column, missingness channel
untouched, 5 permutations averaged), applied to the same trained host whose
attention produces \D. Neutral label in the paper: **"post-hoc readout of
the same host"** / "Permutation-on-SNI". It exists to separate two things
the current recovery axis conflates: the carrier (MissForest vs SNI) and the
artifact type (post-hoc readout vs endogenous attention).

## Fixed placement, regardless of direction

| Table | Included? | Reason |
|---|---|---|
| Recovery (Table 3) | **YES, as a sixth row** | truth is the external synthetic DAG — not circular |
| Stability (Table 4) | **YES, as a sixth row** | real-table A matrices exist per seed (T3.2); cross-seed stability is well-defined |
| Faithfulness (Table 5/6) | **EXCLUDED, with the reason printed in the table note** | the faithfulness ground truth *is* permutation ablation on SNI; the comparator's agreement with it is 1 by construction. The exclusion note doubles as the definition of the axis's truth |
| Cost (Table 7) | **YES** | total cost = SNI fit + permutation audit; it does not rescue SNI's total-cost position and is reported anyway |

Guards change from "five objects or refuse" to **"six objects or refuse"
on recovery / stability / cost, five on faithfulness** — a missing
comparator still kills the table.

## Fixed interpretations (written before the numbers)

- If Permutation-on-SNI **beats** \D on recovery: C3 strengthens — the same
  host's post-hoc readout recovers dependencies better than the same host's
  attention; the carrier explanation is dead.
- If it is **≈ \D**: C3 narrows from "the artifact type is dominated" to
  "this bundle is dominated", and the wording changes in Introduction,
  §5.1 and Conclusions. **Stop condition: report immediately; the first
  author rewrites those passages** (P4-F §4.5).
- Either way, both rows print. No result-dependent placement decisions
  remain to be made after this commit.

## Identity check

Each retrained synthetic host must reproduce the pilot's stored SNI-D matrix
(same recipe, same seed); bitwise agreement expected, deviations reported.
The ablation on real tables reuses T3.2's stored A matrices unchanged.


---

**Addendum (2026-08-29): the information-symmetry clause.**

*This addendum records a rule gap and closes it. It is a correction of the
rules, not a re-run chosen for its result: it is written before the
recomputation it governs has produced a number, and the corrected readouts
are reported whichever direction they move.*

The rules of this project fixed, per axis, what would be compared, against
what reference, and under what decision rule. They did not fix that **the
objects compared under one reference must have had access to the same
information**. On 2026-08-29 an information-symmetry census
(`experiments/information_symmetry_census.py`,
`results/T6_symmetry/information_symmetry_census.json`) found that they had
not: on the recovery, leakage and stability axes, `Permutation-on-SNI`
computes its error signal against the values withheld from the imputer
(`experiments/t4f_perm_on_sni.py:91,106`;
`experiments/t42_leakage.py:413` — `truth = complete[f][miss]`), while every
object it is compared with derives its values from the masked table or from
an imputer's own completion — including its same-type competitor
`Permutation-on-MissForest`, whose `permutation_importance` is scored against
MissForest's own completed values (`experiments/pilot_r21.py:263,281`).

**The clause, applying from this date to every axis:** the objects compared
under one reference must have had access to the same information; where they
have not, the privileged object is aligned **downward** to the common
denominator its competitors already use — never the competitors upward — and
the asymmetry is disclosed in the manuscript whether or not it is corrected.
A real auditor does not hold the withheld values; not holding them is the
fair common denominator.

**Superseded readouts are archived, never overwritten**
(`results/T6_symmetry/superseded_20260829_oracle_error_signal/`), and the old
and new numbers are reported side by side with their difference.
