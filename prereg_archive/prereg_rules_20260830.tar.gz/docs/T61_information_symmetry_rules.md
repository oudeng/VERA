# T6.1 Information symmetry — census rules, recompute rules, and the
# pre-adjudication

**Layer**: audit + defect-correction rule, committed **before the census
exists, before the recompute exists, and before any corrected number has been
seen**. Issued on the first author's adjudication of 2026-08-29 in response to
`reports/P5R_L_S0b_second_finding.md`.

**Zero-artifact attestation (repository state at the commit introducing this
file)**: `results/T6_symmetry/` does not exist;
`experiments/information_symmetry_census.py` does not exist; no no-oracle
ablation matrix exists anywhere in the tree; no recovery or leakage readout
has been recomputed; the pre-adjudication in §5 is written before any of its
inputs can be known.

---

## 1. The rule gap this closes

`docs/T4F_presentation_rule.md` admitted `Permutation-on-SNI` to the recovery
and stability tables on the ground that *"truth is the external synthetic DAG
— not circular"*. That rule covers **circularity**. It does not cover
**information symmetry**: whether the objects being compared had access to the
same information.

They did not. `_ablate` (`experiments/t4f_perm_on_sni.py:91,106`) and its twin
in `experiments/t42_leakage.py:413` compute their error signal against
`complete[f][miss]` — the cells withheld from the imputer — while every object
they are compared with derives its values from the masked table or from an
imputer's own completion.

**From this commit onward, every axis comparison carries a symmetry clause**:
the objects compared under one reference must have had access to the same
information, and any exception is declared and disclosed in the manuscript.

## 2. The census (first author's precondition 1)

`experiments/information_symmetry_census.py` enumerates, for every axis on
which two or more objects are compared under one reference:

- the reference the comparison is made against;
- every object compared;
- for each object, the table its values are derived from, and **whether any
  withheld cell enters its computation** — determined from the source, with
  the file:line quoted;
- the verdict **SYMMETRIC** / **ASYMMETRIC**, and if asymmetric, which objects
  hold information the others lack.

Axes in scope, at minimum:

1. **recovery** — the six objects scored against the synthetic DAG `G`;
2. **leakage** — the six objects scored against the injected proxies;
3. **stability** — the objects scored on cross-seed agreement, including the
   `Permutation-on-SNI` row and the **host band** that `t43_verdict.py` reads
   from `perm_on_sni_real_stability.csv`;
4. **faithfulness** — the reference matrix `A` itself. `D` and `TAP` are
   scored against one ruler, so there is no inter-object asymmetry there; what
   the census must record is `A`'s **semantics**: it is host behaviour measured
   *with privileged information*, not host behaviour simpliciter, and the
   manuscript must say so in those terms;
5. **cost** — timings, no error signal; recorded for completeness.

**The census output determines the recompute list. The recompute runs once,
over the whole list, not in batches.**

## 3. The recompute (first author's precondition 3: align downward)

Where the census finds an asymmetry, the correction is **always** to bring the
privileged object **down** to the common denominator its competitors already
use: an error signal that reads **no withheld cell**. The competitors are
never raised to read truth. A real auditor does not have the withheld values;
the fair common denominator is not having them.

Concretely, for `_ablate` and its leakage twin: the error target becomes the
imputer's own completed values on the same cells — `X_final[f][miss]` — which
is exactly the signal `Permutation-on-MissForest` already uses
(`experiments/pilot_r21.py:263,281`, `y = numeric[target]` from MissForest's
own completion). Nothing else in the ablation changes: the same permutation
count, the same RNG streams, the same standardisation, the same rows.

## 4. The recompute (first author's precondition 2: cold-load before retraining)

Cold-loading was checked before this rule was written, and the result is
recorded here because it constrains what follows:

- **Real-table hosts: archived.** `results/T3_faithfulness/models_*.pt` and
  `Xfinal_*.csv` exist for all 60 real-table runs, and probe 2 already
  cold-loads them. Any real-table recompute is minutes, with **no new training
  randomness**.
- **Synthetic hosts: NOT archived.** `results/T4_perm_on_sni/` holds only
  `D_RETR_*.csv`, `PERM_*.csv` and `meta_*.json`; no weights, no `Xfinal`.
  A synthetic recompute therefore requires retraining, ~3,200 s per cell
  (`meta_*.json`), 15 cells.
- The archived synthetic hosts were **already** not bitwise reproducible: the
  recorded `D_max_abs_diff` against the pilot store is 0.0090–0.0614, not 0.
  A fresh retrain is therefore a different draw either way.

**Consequence, fixed here:** where retraining is unavoidable, the shipped
(oracle) and corrected (no-oracle) matrices are computed **on the same freshly
retrained host**, so the contrast is within-host and the host draw cancels.
The freshly computed oracle matrix is additionally compared with the archived
one, and that distance is reported. The recompute is not permitted to change
any other number by silently substituting a new host: any archived quantity
that moves is reported as moved, with both values.

## 5. The pre-adjudication (fixed before the numbers exist)

The first author fixed the following on 2026-08-29, before the recompute. It
is executed mechanically; no post-hoc reading of it is admissible.

- **If, after the recompute, `Permutation-on-SNI` still beats the strongest
  MissForest-hosted readout** ⇒ the third leg of the §5.1 mechanism argument
  ("the host's function does encode real structure; what fails is the
  artifact") **stands**. The numbers are updated and the disclosure of §6 is
  added anyway.
- **If it no longer beats it** ⇒ the third leg is **removed**: "the window
  exists" and "what fails is the artifact, not the host's function" are
  withdrawn, or narrowed to what the evidence then supports (the fifth
  internal review's P0-6 already required that sentence to be narrowed);
  §5.1 is rewritten to the narrow version, and Fig. 3's recovery cell and
  Table 4 are synchronised with it.
- **In both cases**: the superseded readouts are archived and never silently
  overwritten; the old and new numbers and their difference are reported
  together; `docs/T4F_presentation_rule.md` receives a dated addendum stating
  the rule gap (it covered circularity, not information symmetry) and adding
  the symmetry clause, which from then on applies to every axis.

The comparison that decides this is stated now so it cannot be chosen later:
**the recovery-axis AUROC of `Permutation-on-SNI` against the strongest
MissForest-hosted readout, per regime and pooled, under the estimand the
recovery axis already uses** (mean of seed-level medians, exact enumeration
under seed-block sign-exchangeability, seed-only bootstrap CI).

## 6. Disclosure (first author's option 乙, to be done regardless of direction)

Whatever the recompute shows:

- Table 4's note and §5.1 state that this object's error signal reads cells
  withheld from the imputer while its competitors' do not — and, after the
  correction, that it no longer does;
- the faithfulness reference `A` is described as host behaviour measured
  **against the withheld values**, so a reader knows what the ruler is;
- the stability table's `Permutation-on-SNI` row and the host band derived
  from it carry the same note, in the weaker form that applies there (the
  cross-seed statistic measures the matrix's stability, not its accuracy, but
  the matrix is oracle-derived and its competitors' are not);
- `docs/T4F_presentation_rule.md` gets the dated addendum of §5.

## 7. Outputs

- `results/T6_symmetry/information_symmetry_census.json` — §2;
- `results/T6_symmetry/no_oracle_recompute.json` — old vs new per object per
  regime, the archived-vs-fresh oracle distance, and the §5 decision as
  evaluated by code;
- `results/T6_symmetry/superseded_<date>_oracle_error_signal/` — the
  superseded readouts, verbatim, with a README saying why they are kept;
- a dated addendum in `docs/T4F_presentation_rule.md`.

## 8. What this cannot establish

It establishes what the code computes and what the archived artifacts contain.
Where a host must be retrained because its weights were not archived, the
recomputed numbers come from a different draw of that host than the published
ones; the within-host contrast is what carries the conclusion, and the
archived-vs-fresh distance is reported so a reader can see how much the draw
moved.

---

## Addendum (2026-08-29b): the stability band, and the chain it feeds

*Written before the no-oracle band has been computed. `results/T6_symmetry/`
holds the ten `A_noOracle_*.csv` matrices and `stability_noOracle_cells.csv`
(the per-host oracle-vs-no-oracle agreement) and nothing else; no cross-seed
band has been formed from them, no `T_stab` has been recomputed, and no
mechanism verdict has been re-evaluated.*

Two of the four legs of the §5.1 mechanism argument rest on this object:

- **(i) over-stability** — `\Dm{}` at 0.891 against the *host band* 0.528,
  where that band **is** `Permutation-on-SNI`'s cross-seed stability;
- **(iii) the window** — 0.920 vs 0.912 on recovery, under recomputation.

Legs (ii) (`rho ~ 0.80` with TAP) and (iv) (the `lambda <= ln 2` invariant) do
not involve it.

### The band

The no-oracle band is computed by `t4f_perm_on_sni.stage_real`'s algorithm
verbatim — pairwise Spearman over the entries selected by the first seed's
`notna` mask, all ten pairs per table — applied to the no-oracle matrices.
Nothing else changes.

**Pre-adjudication, fixed here:**

- **the new band remains materially below `\Dm{}`'s 0.891** ⇒ leg (i) stands;
  the numbers are updated and the disclosure is added anyway;
- **the new band is comparable to or above 0.891** ⇒ leg (i) is withdrawn, or
  narrowed to what the evidence then supports, and §5.1, Tables 4 and 5 and
  Fig. 3's stability cell are synchronised with it.

### The chain it feeds

The T4.3 O1 gate takes the band as an input:
`T_stab = host + 0.5 * (D_prior - host)` (`experiments/t43_verdict.py:290`).
`O1` and the mechanism verdict are therefore recomputed with the corrected
band. **If the verdict category changes (MECH-MIXED to anything else), T4.3's
own rule applies: report and stop; the mechanism section is not rewritten
here.** Old and new values are reported side by side and the old ones are
archived, never overwritten.

### Scope limit

The band is computed from the real-table matrices, whose hosts are archived,
so this is a cold load with no new training randomness. It says nothing about
the recovery axis, which is a separate recomputation.

## Addendum (2026-08-29c): the recovery readout, and leg (iii)

*Written before the no-oracle recovery readout has been scored.
`results/T6_symmetry/` holds the thirty recomputed permutation matrices
(`PERM_oracle_*` and `PERM_noOracle_*`, fifteen cells each), their fifteen
`meta_noOracle_*.json` timing records, and `no_oracle_recompute_recovery.json`
-- which contains ONLY per-cell wall-clock and the fresh-oracle-versus-archived
maximum absolute difference. No AUROC has been computed from any of them, no
object has been ranked, and no comparison against the externally hosted
readouts exists. The scoring script named below does not exist yet either.*

### What leg (iii) claims now

> the same-host behavioural probe recovers no worse than the strongest
> externally hosted readout (0.920 vs. 0.912; Table 3)

0.920 is `Permutation-on-SNI`'s mean AUROC over the fifteen synthetic cells and
0.912 is the best mean AUROC among the three externally hosted readouts
(`MissForest-importance`, `SHAP-on-MissForest`, `Permutation-on-MissForest`).
The sentence already carries the asymmetry disclosure; the recompute is what
removes the asymmetry rather than disclosing it.

### How the no-oracle readout is computed

`t4f_perm_on_sni.stage_score`'s algorithm verbatim -- the same `load_cell`,
the same `measured_rows` intersection over all objects in the cell, the same
`score()` -- with one substitution: the `Permutation-on-SNI` matrix is read
from `PERM_noOracle_<regime>_s<seed>.csv` instead of the archived
`PERM_<regime>_s<seed>.csv`. Nothing else changes.

Three objects are scored side by side so the recompute's own two effects stay
separable:

1. **archived** -- the archived matrices, i.e. the number in the paper today;
2. **refit + oracle** -- the freshly retrained host, error signal still scored
   against the withheld values. Isolates what retraining alone moved;
3. **refit + no oracle** -- the freshly retrained host, error signal scored
   against the host's own completed table. This is the symmetric object.

The comparison is run twice and both are reported: once with each variant
scored on its own `common` row set (exactly as the archived recipe would have
scored it), and once with all variants restricted to the intersection of their
row sets (so the head-to-head uses identical rows). If the two disagree in
direction, the intersection version governs and the disagreement is reported.

### Pre-adjudication, fixed here (the first author's, restated mechanically)

- **`Permutation-on-SNI` (refit + no oracle) mean AUROC still at least the
  strongest externally hosted readout's** ⇒ leg (iii) stands; the numbers are
  updated and the asymmetry sentence is rewritten from a disclosure of
  unequal information into a statement that the comparison is now equal;
- **it no longer does** ⇒ leg (iii) is withdrawn or narrowed to what the
  numbers then support, and §5.1, Table 3 and Fig. 3's recovery cell are
  synchronised with it.

Either way the archived readings are kept beside the new ones and are not
overwritten, and the direction is reported whichever way it falls.

### What this cannot establish

Fifteen cells at five seeds is the same floor the recovery axis already
declares: no recovery comparison reaches significance at five seeds, and this
recompute does not change that. The readout is a mean over cells, reported as
such, and the pre-adjudication is stated as a comparison of that mean -- not as
a significance test.

## Addendum (2026-08-29d): the sixth review's closure, written before any of it is measured

*Zero-artifact attestation, true at commit time. `results/T6_symmetry/` holds
the census, the stability recompute and its band, the recovery recompute and
its readout, and nothing else. There is no
`perm_sni_comparison_inventory.json`, no no-prior band under information
symmetry, no fair same-host recovery pair, and no leakage recompute. The three
scripts named below do not exist yet.*

The sixth review's finding, restated so it can be acted on: **the symmetry
correction was applied to some comparisons and the manuscript's claims rest on
others.** What follows fixes, before the numbers, how each remaining one is
handled.

### 1. The inventory is the unit of account

Every place in the manuscript -- main text, ESM, figure text, table captions
and notes -- that compares or states something about `Permutation-on-SNI` is
enumerated and given exactly one of four statuses:

    SYMMETRIC               both sides had the same information
    RECOMPUTED              the no-oracle version is what is reported
    ASYMMETRIC-DISCLOSED    unequal, and said so AT THAT SITE
    ASYMMETRIC-UNDISCLOSED  unequal, and not said there

The disclosure test is mechanical, not a matter of opinion: a site counts as
disclosed only when the text of that site's own unit -- the sentence, or the
table note or figure caption it belongs to -- carries the disclosure. A
disclosure elsewhere in the paper does not make a site disclosed.
**Any ASYMMETRIC-UNDISCLOSED row is a blocker.** The inventory is emitted by
`experiments/perm_sni_inventory.py`, which refuses if a site found in the
sources is not declared, so a new mention cannot enter unnoticed.

### 2. The fair same-host recovery comparison (review SS1)

**Archive check, done before this addendum was written and reported here as a
fact:** the T6.1 recovery recompute saved only the two ablation matrices. It
did not save the host's weights or its `D`. The T4F retrain did archive
`D_RETR_*`, but those belong to a different training run -- its own metadata
records `D_max_abs_diff` up to 0.092 against the pilot store, so training is
not bitwise reproducible here and the T4F host is not the T6.1 host.
**A fair pair is therefore not available by reading. It requires one run that
trains a host and emits, from that same trained model, both `D` and the
no-oracle probe.** Cost: 15 cells at roughly 11 minutes each, about 2.75 hours
of wall clock, machine time only. That cost is reported for adjudication.

**Definition of the fair comparison, fixed here.** For each regime and seed,
one training run; from that run, `D` = `row_normalise(compute_dependency_matrix())`
and `PERM_noOracle` = the ablation with the error signal taken from the host's
own completed table. The two are paired **within host**, so the host draw
cancels. Scoring is `t4f_perm_on_sni.stage_score`'s algorithm verbatim, and
the estimand is the axis's own: T = mean of seed-level medians, seed-only
bootstrap CI, exact sign enumeration at the same five-seed floor.

**Pre-adjudication.**

- **The run completes** ⇒ its result replaces Table 4's same-host row, the
  comparison behind Fig. 3's recovery cell, and the mechanism reading. The
  archived `T = +0.154, p = 0.0625` is kept and labelled *oracle caliber,
  superseded*.
- **The run does not complete** ⇒ the claim that the recovery axis has been
  symmetrically recomputed is **withdrawn**, along with every
  carrier-controlled conclusion drawn from it, and the same-host cell is
  labelled oracle caliber with the disclosure at that site.

Either way, `probe vs strongest external` (recomputed, T = +0.0039) and
`probe vs D` (this section) are **two different comparisons** and neither may
stand in for the other anywhere in the manuscript.

### 3. The no-prior band (review SS3)

**Archive check, reported as a fact:** the no-prior hosts ARE archived --
`models_NP_{ds}_seed{s}_cpu_t2.pt`, `Xfinal_NP_*`, `A_NP_*`, 15 seeds on each
table. So this is a cold load, the same procedure the with-prior band used,
with no new training randomness.

The recompute takes each archived no-prior host, recomputes its ablation with
the error signal from the host's own completed table, and forms the band by
`t4f_perm_on_sni.stage_real`'s algorithm verbatim. A control recomputes the
ARCHIVED band on the same hosts and must reproduce it; if that control does
not reproduce, nothing is reported and the failure is.

**Pre-adjudication.** The measured no-prior no-oracle band replaces 0.489 /
0.478 wherever they appear, and every statement that depends on where the
no-prior `D` sits relative to that band -- `no longer over-stable`, `if
anything conservative`, and the mechanism reading built on them -- is
**rewritten from the measurement, whichever way it falls**. The direction
observed on the with-prior arm is not evidence about this arm and is not used.

### 4. Leakage (review SS4)

The text downgrade does not wait for the recompute and does not depend on it:
the probe's counts are stated as **unequal-information descriptive
positive-control results**, and comparative-superiority wording is withdrawn.
`D` 0/6 against `TAP` 3/6 is unaffected -- neither has the privileged signal --
and remains the axis's formal statement.

The no-oracle leakage recompute is started in parallel because it costs
machine time and no human time. **It is not a packaging blocker.** If it
lands, the inventory rows it covers move to RECOMPUTED; if it does not, they
stay ASYMMETRIC-DISCLOSED with the disclosure at every site.

**A correction to an earlier ruling, recorded rather than quietly dropped:**
the leakage recompute had been made conditional on the recovery comparison
still favouring the probe. Under the sixth review's SS2 that premise is gone --
the recovery result is an inconclusive difference, not a win -- so the
condition cannot excuse the recompute, and does not.

### 5. What none of this establishes

Removing the privileged signal makes the comparisons fair. It does not make
five seeds into a powered design, and it does not turn an inconclusive
difference into an equivalence claim: with no prespecified margin and no
equivalence test, "not shown to differ" is not "shown not to differ", and no
wording in the manuscript may say otherwise.
