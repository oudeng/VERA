# T4F score verdict rule — operationalizing §4.5's "≈" (pre-registered)

**Status: committed before the score stage ever ran.** At commit time
(2026-08-21 20:10) `t4f_sixway_cells.csv` does not exist and no
Perm-vs-D comparison number has been computed anywhere; the training chains
have produced 12/15 matrix pairs, unscored. This closes the last unlocked
judgement point of the phase: the P4-F §4.5 stop condition said
"permutation-on-SNI ≈ D" without defining "≈".

## Primary comparison and caliber

AUROC over the 15 paired cells (3 regimes × 5 seeds), the pilot's
pre-registered scorer and common row set. The host-controlled pair is
**Permutation-on-SNI vs SNI-D-retrained** — bitwise the same host (P4-G
§0.2); the archived-D deltas are reported alongside for pilot-caliber
continuity but do not enter this verdict.

## Verdict: "the post-hoc readout of the same host wins" requires ALL of

1. paired median Δ(Perm − D) > 0;
2. two-sided Wilcoxon p < 0.05 (n = 15 pairs);
3. the direction (median Δ > 0) holds in at least 2 of the 3 regimes.

Any condition failing ⇒ verdict **"indistinguishable"**. In either verdict,
effect size (rank-biserial r) and a seed-bootstrap CI of the median Δ
accompany the p-value — the same ruler as everywhere else — and all four
metrics (AUROC / AUPRC / P@K / SHD) are reported; the verdict reads AUROC
alone.

## Wording consequences, fixed now

- **Wins** ⇒ C3 stated at the artifact-type level: with the carrier held
  fixed, endogenous attention still loses to the same host's post-hoc
  readout.
- **Indistinguishable** ⇒ C3 narrows to the bundle level; Introduction,
  §5.1 and Conclusions change together, and the paper states explicitly:
  on the same host, endogenous and post-hoc readouts could not be
  distinguished — a real conclusion, not the absence of one.
- Declared in advance either way: **narrowing is not retreat.** "The SNI+D
  bundle is dominated" is, for practitioners, the more directly usable
  conclusion; the paper loses nothing by it — the claim's scope becomes
  more accurate.

---

## RETIRED / SUPERSEDED FOR INFERENCE — 2026-08-30

**This rule no longer decides anything.** Its verdict is retained as an
audit-history artifact and is not an input to any generator, any figure, or
any claim in the manuscript.

**Why it was retired.** The rule's conditions treat the fifteen regime x seed
cells as fifteen independent paired observations — condition 2 runs a
two-sided Wilcoxon over them at n = 15. Three regimes are nested inside each
seed, so those fifteen cells are not fifteen independent units. That is the
pseudo-replication this revision corrects everywhere else: the inference unit
throughout is the **seed block** (five of them), and the two-sided exact sign
enumeration over five blocks has an attainable floor of p = 0.0625. The same
comparison therefore reads INDETERMINATE under the corrected unit and WIN
under this rule, and the two cannot both stand.

**Prospective specification does not rescue it.** This rule was written before
any comparison number existed, and that remains true and is not in dispute.
Writing an independence assumption down in advance does not make it hold; a
prespecified analysis with the wrong unit of inference is prespecified and
wrong. Retiring it is the only treatment consistent with the rest of this
revision, which corrected the same error in its own confirmatory analyses.

**What replaces it for the recovery axis.** The comparison and its
direction-independent reporting plan were fixed before scoring; the inference
is the seed-block estimand used throughout the revision, and the fair
same-host pair it is applied to is governed by
`T61_information_symmetry_rules.md` **addendum 2026-08-29d SS2**, which fixed
the pairing, the estimand and the branches before the run.

**What is preserved.** Everything above this marker is unchanged, including
the original conditions and the wording consequences, because a rule that was
followed and then found wanting is evidence about how the work was done. The
verdict string it produced is kept in
`results/T4_perm_on_sni/t4f_verdict.json` and is labelled retired wherever it
is carried forward.

**Raised by:** seventh internal review SS5.1 (2026-08-30).
