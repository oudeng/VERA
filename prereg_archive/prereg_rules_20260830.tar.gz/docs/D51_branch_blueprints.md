# D5.1 branch blueprints — pre-written before the T4.3 verdict ran

**Status: committed before `t43_verdict.py --stage verdict` executed** (at
commit time `results/T4_noprior/t43_verdict.json` does not exist; the
faithfulness axis is mid-training, the synthetic recovery axis is at
3/15 cells; attested in the commit body). Source instrument: P4L
(2026-08-24). Branch selection is **mechanical**: the `mechanism_verdict`
field of `t43_verdict.json` picks the branch — MECH-OPTIMIZED → §2,
MECH-PRIOR → §3, MECH-MIXED → §4. No discretion at selection time; no
claim beyond the selected branch's blueprint may appear.

**Instantiation procedure** (after the verdict): the selected branch is
instantiated as a LaTeX patch on the `\pending{D5.1: ...}` placeholder
(paperY_main.tex:476, §5.1 `sec:why`) plus a compile preview. It is
**not auto-merged**: both narrow branches produce a for-approval merge
draft; the MECH-PRIOR branch first triggers the parent rule's tier-1
mandatory **stop-report** (verdict JSON, all fields, with the
direction-of-surprise stated) and its draft stays provisional until
signed off. Every number in the instantiated text carries a `% src:`
comment naming its JSON field path or table — no hand-copied values.

**Current C3 wording (recorded for diffing)**, abstract Conclusions:

> On these benchmarks, endogenous attention provides no auditable
> information beyond a training-free prior.

---

## §1 Shared skeleton (five paragraphs, all branches)

Placement: the §5.1 placeholder above. Material: the argument structure of
reply W1-Y §3.1, rewritten into paper voice (no reviewer-facing
deixis). Length 350–500 words (~half column). No new figures; only
existing tables are cited.

- **P1 (question, 2–3 sentences)**: the four axes so far are a
  scoreboard — D loses on each. The natural question: does this reflect a
  defect of this module, or a property of this class of artifact? This
  subsection assembles the mechanistic evidence.
- **P2 (four converging observations, ~6 sentences, every number with
  `% src:`)**:
  1. **Over-stability**: D's cross-seed stability exceeds its own host's
     behavioural reproducibility band (eICU: 0.891 vs 0.528, Table 4)
     `% src: fiveway_summary#eICU/SNI-D/stability_mean;
     perm_on_sni_real_stability eICU mean` — an artifact that cannot move
     with its host cannot be reading the host.
  2. **Proximity to the prior**: D is the closest of the six objects to
     TAP (ρ≈0.80, Table 4) `% src: fiveway_summary#eICU/SNI-D/
     rho_with_P_mean` — more like the reference that regularised it than
     any post-hoc readout is.
  3. **The window exists**: the same-host behavioural probe
     Perm-on-SNI recovers no worse than the strongest external readout
     (0.920 vs 0.912) `% src: t4f_verdict.json` — the host's function
     does encode real structure; what fails is the artifact, not the
     host.
  4. **The "controllable" part cannot move**: λ ≤ ln 2 and monotonically
     decreasing — the prior's strength cannot in practice be steered
     away.
- **P3 (load-bearing synthesis, verbatim)**:
  > *Attention weights are an output of the training objective, not a
  > measurement of the trained model. A behavioural probe interrogates
  > the function the host has learned; an internal attention matrix is
  > one of the parameters that optimisation—and any regularisation
  > acting on it—has shaped. The two do not merely differ in cost; they
  > differ in what they are evidence of.*
- **P4 (NoPrior control)**: branch-specific, §2–§4.
- **P5 (scope + C3 + hand-off to Conclusions)**: branch-specific.

**Hard constraints, all branches**:
1. Every citation of the T4.3 verdict is scoped to eICU with MIMIC noted
   untested; the synthetic recovery axis is always labelled pilot
   (15 cells).
2. The `\pending{axis list: fill after T4.2}` placeholder is not touched
   in any way; abstract edits are limited to the scope qualifier before
   "endogenous attention" (fixed per branch below).
3. Ambiguity resolves toward narrowing; no claim beyond the selected
   branch's blueprint.
4. §8.3 tone guard: P5's closing sentence must echo the Conclusions
   frame — "we built the yardstick and measured ourselves first" —
   against the "authors abandon their own method" misreading.

---

## §2 Branch MECH-OPTIMIZED (full width)

**P4**:
> *To test whether the prior alone manufactures this behaviour, we
> retrained the architecture with the prior term removed (eICU, five
> seeds; recovery pilot on 15 synthetic cells). The unregularised
> attention behaved the same way: it did not outperform TAP on either
> axis* `% src: t43_verdict#parent_verdict`*, remained more stable than
> its own host's reproducibility band* `% src: t43_verdict#observables.
> O1_stability_own + filing2_noprior_own_host_band.mean`*, and stayed
> below the pre-registered faithfulness floor* `% src: t43_verdict#
> observables.O2_median_rho`*.*

plus the **O4 sentence slot** (one of three, by reading band
`% src: t43_verdict#O4_reading_band`):
- Reading A: *Notably, even without the prior term the attention matrix
  converged to within 0.10 of its regularised counterpart's proximity to
  TAP (…), indicating that convergence toward marginal correlation
  structure is a property of the optimisation itself rather than of the
  prior.*
- Reading B: *Without the prior term the attention matrix no longer
  tracked TAP (…≤0.50); the proximity documented in observation (ii) is
  thus largely manufactured by the prior, and we rest the account on
  observations (i), (iii) and (iv) together with the control.*
- Intermediate: report the value plus one descriptive sentence; no
  inference.

**P5**:
> *We therefore find no support for attributing the failure to prior
> regularisation specifically. The parsimonious account is structural:
> any internal artefact that is itself part of the training objective
> should not be treated as a measurement of the trained model; it must
> first be audited against a trivial external baseline. This account is
> bounded by the control's scope—single architecture, eICU only (MIMIC
> untested), pilot-scale synthetic recovery—but within that scope every
> observation lines up with it.*

**C3 target wording** (artifact-type level, control scope attached):
> *Endogenous attention, with or without its prior, provided no
> auditable information beyond the trivial baseline on any axis tested
> (no-prior control: eICU); this is consistent with attention being an
> optimisation product rather than a measurement.*

**Abstract qualifier**: keep the type-level phrasing; do NOT add
"prior-regularised". §5.2 same register.

---

## §3 Branch MECH-PRIOR (narrowed + stop-report)

**Procedure**: the parent rule's tier 1 carries a mandatory stop-report —
on this branch, report to the first author FIRST (verdict JSON, all
fields, with the direction-of-surprise stated); the instantiation is a
provisional draft only and does not enter the for-approval merge queue
until signed off.

**P4**: state the separation factually per the rule's fields (axis name,
median Δ, Wilcoxon p, all with `% src:`), then:
> *This reverses the attribution: the auditability failure documented
> above is manufactured by the prior—regularisation pulls the artefact
> onto the very reference against which it is then audited, a
> circularity by construction.*

plus the O4 sentence slot (same three readings as §2).

**P5** (narrowed + open question made explicit, overselling forbidden):
> *The narrower lesson stands: an internal artefact regularised toward a
> reference re-expresses that reference, and auditing it against that
> reference is then uninformative by construction. Whether unregularised
> endogenous attention constitutes a usable audit artefact is beyond
> this paper's scope—the signal here is single-table (eICU; MIMIC
> untested) and pilot-scale, and warrants a dedicated study.*

**C3 target wording**: narrowed to *prior-regularised endogenous
attention*. **Abstract qualifier**: add "prior-regularised"; no positive
finding may appear in the abstract. §5.2 same register.

---

## §4 Branch MECH-MIXED (narrowed + deviation report)

**P4**: report the tier plus the deviation list verbatim
(`t43_verdict#mechanism_deviations`), then by sub-case:
- **(a) O2-only deviation** (filing-1 case; the verdict JSON attaches
  the with-prior same-table value automatically):
  > *The floor criterion is calibrated on MIMIC, where the regularised
  > artefact breaches it; on eICU the regularised artefact itself sits
  > above the floor (0.364* `% src: fiveway... faithfulness_summary#
  > eICU/SNI-D/rho_median`*), so this criterion is conservative for the
  > present control.*
  The wording register stays narrow; this sentence is a factual filing
  only.
- **(b) O1 deviation** (NoPrior not over-stable): state explicitly that
  the attribution of observation (i) partly belongs to the prior; the
  mechanism argument weakens accordingly and rests on (ii)–(iv) plus the
  control's remaining readouts.
- **(c) BORDERLINE landing here**: direction without significance —
  report direction and p as they are; no claim.

**P5**: §3's P5 conditional sentence, minus its positive-finding clause
("the signal here…" part removed where it asserts a finding); C3 and the
abstract qualifier as §3 (narrow register). O4 sentence slot as §2.

---

## Timing note

Committed before any verdict execution; if that ordering had been
missed, this file would say so here rather than claim otherwise (P4L
header clause).

---

**Erratum (2026-08-24, per P4M §1)**: §4 的 "C3 与摘要限定词同 §3" 仅在
parent=DIFFERENT-TYPE 时适用(该情形已由 §3 支覆盖);MECH-MIXED 且
parent=SAME-TYPE 时,C3/摘要档位从母规则 SAME-TYPE 固定措辞(类型层)。
(起草文档勘误,非判决规则修改;错键责任在起草侧,见 P4M §1。)
