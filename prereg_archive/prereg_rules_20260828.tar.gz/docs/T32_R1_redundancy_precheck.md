# T3.2-R1 — redundancy robustness pre-check (supplement to 6030500)

**Status: pre-registered.** Committed 2026-08-20 ~17:4x JST, while both T3.2
training chains were still on their first runs and **zero** `A_*.csv` existed
on disk (verified by file listing immediately before this commit; no A matrix,
no faithfulness statistic, and no analyze output had been produced or seen).
Supplements the decision rule at commit `6030500`; does not modify it.

## Why (the bias this guards against)

`A[f,j]` is permutation-based. Permutation importance is known to
**under-credit correlated sources**: if j and k are highly correlated,
permuting j alone leaves k standing in for it, so `A[f,j]` under-states the
model's real reliance on j. MIMIC and eICU are exactly such tables (blood
pressure family, rate family). P gives correlated variables high weight by
construction, so this artifact would deflate `rho(P,A)` specifically — i.e.
**it tilts the D-vs-P comparison in D's favour**. A home-ground win must not
rest on it.

## The check (run after the 6030500 verdict, whatever that verdict is)

1. Per dataset, redundant source set
   `R = { j : exists k != j with C[j,k] > 0.8 }`, where `C` is the
   feature-level pooled |Pearson| correlation computed **on the complete
   table** with the prior's own type-aware recipe (one-hot for categoricals,
   mean-pooled across dims — `_compute_correlation_prior` +
   `_extract_feature_prior`, WITHOUT the row normalisation). The 0.8
   threshold is fixed here, in advance.
2. Recompute every one of the five methods' row statistics against A
   (Spearman / top-k overlap / AUROC-top3) using only sources **outside R**
   (targets unchanged; per target the source set is `feats \ {f} \ R`).
3. Report both sets side by side — all sources vs. redundancy-excluded —
   regardless of which favours us.

## Operationalisation of §3's qualitative terms (fixed now, not after)

Let Delta_full = median over (seed, target) pairs of rho_D − rho_P on all
sources (per dataset), and Delta_excl the same on the excluded set (pairs with
≥ 5 kept sources).

* **"优势基本保持" (advantage holds)** — ALL of, in BOTH datasets:
  (a) median Delta_excl > 0; (b) Delta_excl ≥ 0.5 × Delta_full;
  (c) paired Wilcoxon on the excluded-set deltas p < 0.05.
  The conjunction mirrors 6030500's both-datasets rule and resolves the
  ambiguity against our own method.
* **"显著缩小或消失" (artifact-driven)** — anything else: the "D more
  faithful than P" component must be restated at the shrunken magnitude, and
  this analysis goes into the ESM.
* **Not applicable** — if, in a dataset, R is empty or fewer than 5
  non-redundant sources remain per target (n_keep − 1 < 5): state so, report
  the numbers that exist, do not force a verdict for that dataset; the
  applicable dataset(s) alone then carry the check.

The main verdict is still read from 6030500 first; this check qualifies the
ROW1 reading (and is reported even under ROW2/ROW3, since the same artifact
could also mask a real D advantage — the direction of the bias is what makes
the check one-sided in D's favour, so its absence of effect is evidence, not
decoration).
