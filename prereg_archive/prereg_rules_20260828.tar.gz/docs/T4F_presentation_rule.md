# T4F presentation rule — permutation-on-SNI (pre-registered)

**Status: committed before any permutation-on-SNI number existed.** At commit
time the pilot's synthetic cells have no stored SNI models (verified by
listing), no synthetic ablation matrix has been computed, and no cross-seed
stability of the real-table A matrices has been calculated. This file fixes
how the comparator is REPORTED, whichever way its numbers fall — the same
discipline as the pilot rule, 6030500 and 00a7984, and it matters more here
than there: this is a comparator we proposed ourselves and that could favour
us, so its presentation must be locked before its results exist.

## What it is

Permutation importance computed on SNI itself: T3.2's ablation machinery
(row-wise permutation of the standardized input column, missingness channel
untouched, 5 permutations averaged), applied to the same trained host whose
attention produces \D. Neutral label in the paper: **"post-hoc readout of
the same host"** / "Permutation-on-SNI". It exists to separate two things
the current recovery axis conflates: the carrier (MissForest vs SNI) and the
artifact type (post-hoc readout vs endogenous attention).

## Fixed placement, regardless of direction

| Table | Included? | Reason |
|---|---|---|
| Recovery (Table 3) | **YES, as a sixth row** | truth is the external synthetic DAG — not circular |
| Stability (Table 4) | **YES, as a sixth row** | real-table A matrices exist per seed (T3.2); cross-seed stability is well-defined |
| Faithfulness (Table 5/6) | **EXCLUDED, with the reason printed in the table note** | the faithfulness ground truth *is* permutation ablation on SNI; the comparator's agreement with it is 1 by construction. The exclusion note doubles as the definition of the axis's truth |
| Cost (Table 7) | **YES** | total cost = SNI fit + permutation audit; it does not rescue SNI's total-cost position and is reported anyway |

Guards change from "five objects or refuse" to **"six objects or refuse"
on recovery / stability / cost, five on faithfulness** — a missing
comparator still kills the table.

## Fixed interpretations (written before the numbers)

- If Permutation-on-SNI **beats** \D on recovery: C3 strengthens — the same
  host's post-hoc readout recovers dependencies better than the same host's
  attention; the carrier explanation is dead.
- If it is **≈ \D**: C3 narrows from "the artifact type is dominated" to
  "this bundle is dominated", and the wording changes in Introduction,
  §5.1 and Conclusions. **Stop condition: report immediately; the first
  author rewrites those passages** (P4-F §4.5).
- Either way, both rows print. No result-dependent placement decisions
  remain to be made after this commit.

## Identity check

Each retrained synthetic host must reproduce the pilot's stored SNI-D matrix
(same recipe, same seed); bitwise agreement expected, deviations reported.
The ablation on real tables reuses T3.2's stored A matrices unchanged.
