# T4.2 confirmatory replication rules (P5R-B SS4-A2; internal review SS4.7 must-fix 5)

**Timing disclosure**: written after the original T4.2 results and their
generation stratification were known -- that mixing is exactly what this
replication addresses. Committed BEFORE any confirmatory run exists: at
commit time no run directory with host seed 5, 8 or 13 exists anywhere
under `results/T4_leakage/runs/` (attested in the commit body). Every
free choice below is fixed here; the analyzer refuses to compute anything
while any planned run is missing, so there is no optional stopping.

## Question

The shipped interaction-class result mixes construction generations
(gen-2: 3 injections, gen-3: 3; stratified in
`t42_summary.json > interaction_by_generation`). This replication asks
whether the interaction reading holds on the **frozen gen-3
construction** -- the `make_proxy` interaction path exactly as committed
in `3f71b02` (linear residualisation on the target, guards unchanged:
marginal |corr| < 0.10, joint predictivity > 0.5, degeneracy < 0.20,
ranked partner fallback) -- with fresh host seeds and fresh proxy draws.

## Design (all fixed before any run)

- Condition: **interaction only**; kinds inj + null; datasets MIMIC, eICU.
- New host seeds: **5, 8, 13** (the project's Fibonacci convention,
  disjoint from the original 1, 2, 3). 2 x 3 x 2 = **12 host retrains**.
- Targets: the same pre-registered ranked attack targets
  (`attack_targets`), rotation extended by seed index mod 3: seed 5 ->
  rank-1 target, 8 -> rank-2, 13 -> rank-3. Identical target set to the
  original; one fresh host per cell.
- Proxy randomness: the existing stream formula with seed indices 3, 4, 5
  (originals used 0, 1, 2), so every confirmatory draw is disjoint from
  every original draw; the null permutation stream is keyed by the seed
  VALUE and is likewise fresh. Original tags/streams are untouched.
- **No new calibration.** Detection thresholds are reused from the
  original per-(object, dataset, target-row) calibration pool (21 runs
  per dataset, host seeds 1-3, the n >= 20 gate already passed).
  Assumption, disclosed: the calibration score distribution is
  exchangeable across host seeds -- the original design already pools
  three host seeds into one threshold. A per-new-seed calibration
  (+42 retrains, roughly +50 machine-hours) is priced in the receipt,
  not run.
- Slow-run canary: same archived + self-calibrated triplines as the
  original workers (stop + investigate + report; never a verdict gate).
- Per-run containment as in the original workers (a failed run is logged
  and skipped; the analyzer's missing-run refusal keeps it visible).

## Readout (fixed here; all exact/descriptive)

Per object: detected/6 on injections with Wilson 95% interval;
detected/6 on nulls (nominal alpha = 0.05).

1. Side-by-side: confirmatory 6 vs the original gen-3 stratum (n=3);
   plus pooled frozen-construction counts out of 9, labeled
   "gen-3 pooled (3 original + 6 confirmatory)". Pooling is a labeled
   convenience row, not a substitute for the stratified counts.
2. D vs TAP exact McNemar (two-sided binomial on discordant pairs) on
   the 6 confirmatory pairs and on the 9 pooled gen-3 pairs.
3. Null false positives: exact binomial P(X >= k | n=6, p=0.05) per
   object, descriptive.

**Role**: this replication is labeled *confirmatory* and qualifies the
generation-stratified reporting (P5R SS4.2). It gates no pre-registered
verdict: the leakage-axis sentence follows the stratified gen-3 numbers
with the mixed-generation history disclosed regardless of how the
replication lands.

## Outputs

`results/T4_leakage/t42_confirmatory.json`; per-run artifacts under
`results/T4_leakage/runs/{DS}_s{5,8,13}_interaction_{inj,null}/` (tags
are disjoint from all original tags by the seed component). Prose cites
fields; no hand-copied count.
