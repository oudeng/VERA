# T4F score verdict rule — operationalizing §4.5's "≈" (pre-registered)

**Status: committed before the score stage ever ran.** At commit time
(2026-08-21 20:10) `t4f_sixway_cells.csv` does not exist and no
Perm-vs-D comparison number has been computed anywhere; the training chains
have produced 12/15 matrix pairs, unscored. This closes the last unlocked
judgement point of the phase: the P4-F §4.5 stop condition said
"permutation-on-SNI ≈ D" without defining "≈".

## Primary comparison and caliber

AUROC over the 15 paired cells (3 regimes × 5 seeds), the pilot's
pre-registered scorer and common row set. The host-controlled pair is
**Permutation-on-SNI vs SNI-D-retrained** — bitwise the same host (P4-G
§0.2); the archived-D deltas are reported alongside for pilot-caliber
continuity but do not enter this verdict.

## Verdict: "the post-hoc readout of the same host wins" requires ALL of

1. paired median Δ(Perm − D) > 0;
2. two-sided Wilcoxon p < 0.05 (n = 15 pairs);
3. the direction (median Δ > 0) holds in at least 2 of the 3 regimes.

Any condition failing ⇒ verdict **"indistinguishable"**. In either verdict,
effect size (rank-biserial r) and a seed-bootstrap CI of the median Δ
accompany the p-value — the same ruler as everywhere else — and all four
metrics (AUROC / AUPRC / P@K / SHD) are reported; the verdict reads AUROC
alone.

## Wording consequences, fixed now

- **Wins** ⇒ C3 stated at the artifact-type level: with the carrier held
  fixed, endogenous attention still loses to the same host's post-hoc
  readout.
- **Indistinguishable** ⇒ C3 narrows to the bundle level; Introduction,
  §5.1 and Conclusions change together, and the paper states explicitly:
  on the same host, endogenous and post-hoc readouts could not be
  distinguished — a real conclusion, not the absence of one.
- Declared in advance either way: **narrowing is not retreat.** "The SNI+D
  bundle is dominated" is, for practitioners, the more directly usable
  conclusion; the paper loses nothing by it — the claim's scope becomes
  more accurate.
