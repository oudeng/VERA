# T2d.1 decision rule — fixed before any measurement was taken

P2d §1 sets the rule; P2d §8 requires it to be written down and committed *before*
the results are looked at, because "should SNI stay on the GPU" is a question that
has already been answered wrongly once (P2c §4.1, withdrawn as B81).

This file is that commitment. It is committed in its own commit, ahead of the
commit that adds any T2d.1 result. Nothing below may be edited afterwards; a
change of rule must be a new dated section that says what changed and why.

---

## The verdict

**SNI moves to the CPU queue and the grid stays at 2565 cells** if and only if
**all three** conditions below hold.

### C1 — cost

    per-cell wall-clock on CPU  <=  3.0 x  per-cell wall-clock on CUDA

Evaluated per dataset on **MIMIC, NHANES, Concrete**, MAR@30 %, seed 1, under the
P2c protocol (200 epochs, early stopping disabled). **C1 must hold on every one of
the three**, not on their mean — a mean would let one cheap dataset hide an
expensive one.

The CUDA side is *already measured*: the P2c smoke arm ran exactly this
configuration (`results/T2b_smoke/gpu.log`), giving MIMIC 1952.0 s, NHANES
1895.7 s, Concrete 123.5 s. Those numbers are reused rather than re-run. The
`SNI/AutoMPG` timing from that same log is void (B81) and is not used anywhere.

### C2 — concurrency

    per-cell wall-clock at 12-way CPU concurrency  <=  1.5 x  per-cell wall-clock solo

"Per-cell" means batch wall-clock divided by the number of jobs in the batch, and
it counts only batches where **every** job completed. A batch with
`n_completed < concurrency` fails C2 outright — that is how the GPU queue failed,
and the measurement must not be allowed to look better by ignoring the jobs that
never finished.

### C3 — metrics

The CPU/GPU difference must be no larger than the spread the same metric already
shows across seeds on a single device:

    |R2_cpu(d, seed 1) - R2_cuda(d, seed 1)|  <=  max_seed R2_cuda(d) - min_seed R2_cuda(d)

evaluated per dataset `d` over the 3 seeds measured in the §4 protocol comparison,
on `cont_R2` and on `cont_NRMSE`. Float differences between CPU and CUDA are
expected and are not by themselves a problem; a difference *larger than seed
noise* is, because it would mean device-dependent behaviour rather than
device-dependent rounding.

If a dataset's cross-seed spread is degenerate (all three seeds identical to
7 significant figures), fall back to an absolute tolerance of **1e-3 on R²** for
that dataset, so that a zero-variance denominator cannot make C3 unfalsifiable.

---

## What happens if the verdict is negative

Fallback order is fixed by P2d §1 and is **not** re-orderable by the measurement:

1. **CDC2022 down-sampled to n = 1500 or 1000, keeping d = 41.** R2-4 needs table
   *width*, not sample size.
2. SNI on CDC2022 restricted to MAR@30 % x 5 seeds (drop MCAR), matching Table 3's
   existing protocol.
3. **Seeds last.** Cutting seeds directly weakens the cross-seed stability evidence
   that is the reason CDC2022 is in the grid at all.

---

## Reporting obligations attached to the rule

* Every extrapolated number carries its uncertainty. Three cost models have already
  failed badly on CDC2022 (by >=18x, >=6.8x and >=3.4x); a fourth unqualified
  point estimate is not acceptable.
* Peak RSS at 12-way concurrency is reported whether or not it affects the verdict.
* If CDC2022 on CPU has not finished within 6 h, it is estimated from an n=1000
  down-sample and scaled by rows, **with the scaling assumption stated and its
  error bar given**.

---

Written 2026-07-29, before the first T2d.1 run was launched.
