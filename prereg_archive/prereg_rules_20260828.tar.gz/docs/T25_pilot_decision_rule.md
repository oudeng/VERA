# T2.5 (R2-1 pilot) go/no-go rule — fixed before any pilot run

P2e §1.3 and §11 require this written and committed before results are seen,
because the pilot is "这次修订里最容易被期望污染的一步". The same discipline was
applied to T2d.1 (`docs/T2d1_decision_rule.md`, committed 686702f), and it is
what made a negative verdict there believable.

This file is that commitment, in its own commit ahead of any pilot result.
Nothing below may be edited afterwards; a change must be a new dated section
stating what changed and why.

---

## What the pilot is deciding

Not "is SNI-D good". Whether the **paper's current positioning of D as an audit
artefact survives contact with the strongest post-hoc alternatives**. The
positioning is what a negative result would force us to rewrite, so the rule is
written against the positioning, not against a metric.

The existing evidence that motivates caution: B13 measured D against SHAP on
ALARM at ρ = −0.357, not significant, single seed, n = 7 sources. **The argument
must therefore not rest on "D resembles SHAP."** Axis A (recovery of a known
DAG) is the load-bearing axis; agreement with a post-hoc explainer is not a
target at all.

## Comparators (all produce a d×d directed matrix)

1. **SNI-D** — endogenous, free at training time
2. **MissForest `feature_importances_`** — per-column RF importances stacked to
   d×d. The most isomorphic and the strongest opponent.
3. **SHAP-on-MissForest** — surrogate per target on MissForest-completed data, TreeSHAP
4. **Permutation importance on MissForest**

## Hyperparameters (fixes B18)

Axis A uses the **main-experiment** hyperparameters: `epochs=200`,
`num_heads=16`, `emb_dim=128`, `hidden_dims=[256,128,64]`, early stopping
disabled (the P2c protocol). R0's synthetic experiment used `epochs=50`,
`heads=4`, `emb=32`, so its "Prior-Only wins" conclusion may be an artefact of
under-training. Running the pilot at the downgraded settings would inherit that
defect.

---

## The rule

**Primary metric, axis A:** AUROC of the recovered edge ranking against the true
DAG, paired over the 15 (regime, seed) cells — 3 regimes x 5 seeds.

Let `A_SNI` be SNI-D's mean AUROC and `A_best` the highest mean AUROC among the
three post-hoc comparators. Let `Δ = A_SNI − A_best`, tested paired across the
15 cells with a two-sided Wilcoxon signed-rank test at α = 0.05.

### GO — positioning holds as written

`Δ ≥ −0.02`, **or** the paired test is not significant (`p ≥ 0.05`).

Reading: SNI-D recovers structure about as well as the best post-hoc method, so
its cost and dependency advantages (axes C, D) are gained for free rather than
bought with accuracy.

### CONDITIONAL GO — positioning narrows, and P3/P5 must be rewritten

`Δ < −0.02` **and** `p < 0.05`, **but both**:

* axis C: SNI-D's total wall-clock (impute + audit) ≤ **50 %** of `A_best`'s
  method's total, and
* axis D: SNI-D needs neither a trained downstream model nor ground truth, while
  `A_best`'s method needs at least one.

Reading: D is not the most accurate structure recovery available, but it is the
only one obtainable before any downstream model exists. The claim shrinks to a
**free, model-free first-order audit signal** — explicitly not "better than
post-hoc explainers".

### NO-GO — the positioning does not survive

`Δ < −0.02` and `p < 0.05` and the CONDITIONAL GO conditions do not both hold.

### Independent NO-GO — instability, regardless of axis A

Median pairwise cross-seed Spearman of SNI-D (axis B) **< 0.5**.

An audit tool that does not reproduce across seeds cannot be published as an
audit tool, however well it scores on recovery. This overrides GO. The threshold
is set at 0.5 because R0 claims ρ = 0.951 on real MIMIC data; a tool an order of
magnitude less stable than its own published claim is not the tool described in
the paper.

---

## Reporting obligations attached to the rule

* **AUPRC, Prec@K and SHD are reported for every method whether or not they
  agree with AUROC.** If they disagree with the AUROC-based verdict, that
  disagreement is the finding and goes in the report.
* If SNI-D loses on axis A, that is reported as-is. **No search for a
  configuration in which it wins.** P2 T2.5 states this and it is repeated here
  because it is the specific failure this rule exists to prevent.
* Cost (axis C) is measured as **impute + audit total**, per P2 T2.5: SNI's D is
  a training by-product while the SHAP path needs a surrogate fit plus TreeSHAP.
  Comparing imputation cost alone would flatter the wrong method.
* The synthetic ground truth, the 3 regimes and the 5 seeds are fixed before the
  run and recorded; regimes are not added or dropped after seeing results.
* Cross-database D consistency (MIMIC vs eICU on the shared schema) is a
  **supporting** axis. A positive result strengthens the case; a negative one
  does not by itself change the verdict, because the two databases differ in
  population as well as in schema.

---

Written 2026-07-30, before the first pilot run was launched.
