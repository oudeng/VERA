# T4.3 interpretation supplement — mechanism attribution (pre-readout)

**Status: committed before any NoPrior readout existed.** Training for both
axes was launched 2026-08-23 23:55 under the parent rule; at commit time the
NoPrior artifact set is empty (two zero-byte training logs, no `NP_*` files,
no synth-axis outputs, `--stage analyze` never invoked for the variant; the
listing is attested in the commit body). The parent rule
(`T43_noprior_decision_rule.md`, commit `6535787`) is **not modified**: its
tiers, thresholds and precedence stand unchanged. This file adds a second,
separately-named output — mechanism attribution for Discussion §5.1 — plus
two readout requirements, so that §5.1's width is fixed by rule rather than
chosen after the numbers are seen (P4K §2; background: handover v2 §8.2).

## Why a second output

The NoPrior control answers two different questions:

- **(a) C3 scope** (parent rule): is the negative conclusion about the
  prior-regularised CPFA module, or about attention-derived reliance
  matrices as a type?
- **(b) Mechanism** (this file): if NoPrior attention behaves like prior
  attention — still over-stable, still unfaithful — the fault lies in
  "attention is optimised, not measured" itself, and §5.1 may state the
  generalised form at full width. If NoPrior attention is clearly
  different, the fault is the prior regularisation and §5.1 narrows to
  "prior-regularised attention".

## Observables (computed by code; calibers pinned by recompute-assertion)

All on eICU (the axis's table; scope in §"eICU-only" below). Reference
values are **read from stored artifacts at runtime**, never hand-copied:

- **O1 — NoPrior-D cross-seed stability**, exactly the five-way caliber
  (pairwise Spearman across the 5 seeds, own-rows; rows12 printed
  alongside as the second caliber). References at runtime:
  `results/T3_five_way/fiveway_summary.json → /eICU/SNI-D/stability_mean`
  (with-prior D) and the mean over the 10 eICU pairs of
  `results/T4_perm_on_sni/perm_on_sni_real_stability.csv` (host-behaviour
  reproducibility). **Mandatory same-caliber self-check**: the readout
  first recomputes with-prior D stability from the stored
  `D_retrained_eICU_seed*_cpu_t2.csv` files and asserts agreement with the
  stored summary value to 1e-3 before computing O1. A failed assertion
  stops the readout (caliber drift is this project's most recurrent
  failure class).
- **O2 — absolute faithfulness**: the parent rule's primary statistic
  (median row-level Spearman rho(NoPrior-D row, A row) over the 60
  (target, seed) pairs) against the 0.30 floor already fixed there.
- **O3 — the parent tier verdict** (SAME-TYPE / BORDERLINE /
  DIFFERENT-TYPE), computed by the parent rule.
- **O4 — rho(NoPrior-D, P)**, five-way own-rows caliber, mean over seeds;
  same self-check against `/eICU/SNI-D/rho_with_P_mean` (stored 0.7982)
  recomputed from the stored with-prior artifacts. **O4 gates nothing**
  (reading bands below).

## Mechanism verdict (precedence top-down; ambiguity resolves toward narrowing)

Let `host` = eICU host-reproducibility mean, `Dp` = with-prior D stability
mean (both read as above), and

    T_stab := host + 0.5 * (Dp - host)

(NoPrior attention at least halfway from host behaviour toward the
with-prior over-stability = "still over-stable").

1. **MECH-PRIOR** iff O3 = DIFFERENT-TYPE. §5.1 scopes the mechanism claim
   to prior-regularised attention; the generalised sentence is not
   asserted. (This tier coincides with the parent rule's mandatory
   stop-report, which proceeds unchanged.)
2. **MECH-OPTIMIZED** iff O3 = SAME-TYPE **and** O1 >= T_stab **and**
   O2 < 0.30. §5.1 states the mechanism at full width: attention weights
   are products of the training objective, not measurements of the fitted
   function; the generalised form ("any internal artifact that is itself
   part of the training objective cannot be treated as a measurement of
   the trained model") may be asserted, with the NoPrior control cited as
   its deciding experiment.
3. **MECH-MIXED** otherwise. The deviating observable(s) are reported
   factually; §5.1 takes the narrow ("prior-regularised attention")
   wording. BORDERLINE on O3 lands here by construction.

The verdict is emitted by the readout code as a named field
(`mechanism_verdict`) next to the parent tier; no human reads numbers into
either.

## O4 reading bands (fixed now; descriptive, non-gating)

- **Reading A** (strengthens the optimised-object argument) iff
  O4 >= rho_prior − 0.10, where rho_prior is the recomputed with-prior
  value: attention re-converges to marginal-association structure with the
  prior pull removed, so the with-prior closeness to TAP was not
  manufactured by the regulariser.
- **Reading B** (closeness substantially prior-manufactured) iff
  O4 <= 0.50: stated as such, and the corresponding step of the §5.1
  evidence chain (handover v2 §8.1 point 2) is weakened accordingly —
  reported at that strength, not argued around.
- Otherwise intermediate: the value is reported without argumentative use.

Either way O4 does not move the mechanism verdict; it calibrates how one
sentence of the argument may be phrased.

## eICU-only scope (recorded reasons; binding wording consequence)

The axis runs on eICU × 5 seeds only. Recorded reasons, both predating the
parent rule commit (`reports/P4_T41_report.md`): per-run cost at planning
(~3720 s vs ~5500 s for MIMIC), and the same report's R1-sensitivity
result — eICU is the table whose faithfulness deficit **sharpens** when
redundant sources are excluded (p 0.069 → 0.0012 at tau = 0.5), i.e. the
table most defensible against the objection that the deficit is a
redundancy artifact. Consequence, binding for the paper: the NoPrior
control is a **single-table** control; wherever its verdict is used, the
text scopes it to eICU and states that MIMIC is untested for this variant.
The parent rule's generality verdict is unaffected by this scoping.

## Boundary note

This supplement was specified after the with-prior results (T3.1/T3.2/T4F)
were known — like every interpretation layer — but **before any NoPrior
number existed**. It adds interpretation and readout requirements only; it
changes no clause of the parent verdict rule.
