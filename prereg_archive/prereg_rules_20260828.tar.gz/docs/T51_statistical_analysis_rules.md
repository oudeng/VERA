# T5.1 cluster-robust statistical analysis rules (P5R SS1; internal review SS4.3)

**Timing disclosure**: specified after the primary data existed (they are
the grid-era artifacts) and after the original n=60 Wilcoxon results were
known -- that is exactly the defect under repair. Committed BEFORE any
cluster-robust quantity below was first computed: at commit time no
seed-block permutation p, no hierarchical bootstrap interval, and no
per-class exact paired test exists anywhere in the repository (attested
in the commit body). Free parameters are fixed here by formula or
enumeration; the wording consequences are the two branches pre-written in
the P5R instrument (SS1.3), selected mechanically.

## Units and cluster structure

The observation grid for the faithfulness families is target x seed:
12 targets share a seed's trained host (and table, and mask), and a
target repeats across the 5 seeds -- a crossed clustering in which the
60 pairs are not independent. The independent replication unit for
training randomness is the **seed**; there are five.

## Methods (the feasibility pair, per P5R SS1.2)

Chosen two of the instrument's three options:

1. **M1 -- exact seed-block sign-flip test.** Under the null that the
   paired difference distribution is sign-symmetric at the seed level,
   flip the sign of ALL differences of a seed jointly; enumerate all
   2^5 = 32 flips exactly. Statistic: the median of all paired
   differences. Two-sided p = share of flips with |statistic| >= the
   observed |statistic| (the identity flip counts, as always).
   **Granularity floor, stated in advance as a property of the design,
   not of the data: with five seeds the smallest attainable two-sided p
   is 2/32 = 0.0625 (one-sided 1/32 ~ 0.031). No two-sided seed-block
   test can reach 0.05 at n=5.** This floor is disclosed wherever the
   test is reported.
2. **M2 -- hierarchical bootstrap CI.** Resample seeds with replacement
   (5 draws), then targets with replacement within each drawn seed;
   statistic = median paired difference; 10,000 resamples, rng seed
   20260828; percentile 95% interval. Reported as the uncertainty
   statement accompanying M1; no bootstrap p is derived at n=5 seeds.

Both levels of aggregation are printed alongside (seed-level five
medians; target-level twelve medians with a sign count), descriptively.

## Families under re-inference (P5R SS1.2)

1. **Faithfulness, primary endpoint**: paired Delta rho (D - TAP), full
   scope, per table (MIMIC, eICU). Primary family = these two tables;
   Holm over the two M1 p-values. This is the family the abstract cites.
2. **NoPrior faithfulness** (eICU, 60 pairs): same machinery.
3. **Recovery and NoPrior recovery** (15 cells = 3 regimes x 5 seeds):
   seed-block sign-flip across the five synthetic seeds (statistic =
   median of the 15 paired differences), hierarchical bootstrap seed ->
   regime. Same floor disclosure.
4. **Leakage, per class**: 6 paired detection outcomes (D vs TAP) per
   condition; exact McNemar (binomial on discordant pairs, two-sided).
   Counts are already on disk; no retraining.

Multiplicity: Holm within each family as defined above; families are not
pooled with each other. Adding Holm alone is NOT the repair (the rules
exist because the unit was wrong, not the correction).

## Branch selection (mechanical, per P5R SS1.3)

For each family: **Branch S** iff the M1 Holm-corrected two-sided p
< 0.05 (attainable only for families whose enumeration space allows it);
otherwise **Branch N**, whose fixed wording is the instrument's:
direction persists (median Delta reported) but does not reach
significance under cluster-robust inference; the comparison is reported
as showing no evidence that D exceeds the baseline, not as a significant
deficit. Neither branch touches the "no auditable information beyond
TAP" umbrella sentence; abstract/conclusion wording follows the branch
via the for-approval patch.

## Outputs

`results/T5_stats/t51_cluster_stats.json`: per family -- observed
statistic, exact enumeration distribution size, two-sided and one-sided
M1 p, Holm-corrected p within family, M2 interval, both aggregation
levels, branch. The old n=60 Wilcoxon values are carried alongside for
the before/after table required by the receipt. Prose and patches cite
fields (`% src:`); no hand-copied statistic.

## Seed expansion

15-20 seeds (internal review SS4.3.3) is priced separately in the P5R
receipt and is NOT assumed by these rules; if adopted later, the same
rules apply unchanged with a finer enumeration floor (2^15 flips).

---

**Corrigendum (2026-08-28, pre-computation; zero cluster-robust artifacts
at commit time)**: M1's test statistic said "the median of all paired
differences". Building the selftest showed that statistic is
non-monotone under joint block flips (flipping the least-negative block
can make the pooled median MORE extreme) and tie-prone, so the disclosed
2/32 floor is not generally attainable and the test's power ordering is
erratic. The test statistic is corrected to **the mean of the five
seed-level medians** -- robust within a block, linear across blocks, so
the identity and mirror flips are the unique extremes for coherent data
and the disclosed floor is exact. The pooled median remains the reported
effect size; nothing else changes. Caught by the runner's selftest
before any real family was computed.

---

**Addendum (2026-08-28, P5R-B §3 adopted by the first author; committed
before any expanded-seed artifact exists)**: seed expansion 5 -> 15 for
the faithfulness families (MIMIC, eICU) and the NoPrior faithfulness
family. The ten additional seeds continue the existing convention's
Fibonacci sequence and are fixed here, before any training:
**13, 21, 34, 55, 89, 144, 233, 377, 610, 987.** Units, statistic,
branch mapping and every other clause are unchanged; the exact
enumeration becomes 2^15 = 32,768 flips (two-sided floor ~6.1e-5).
Branch re-selection after the 15-seed readout is mechanical as before;
the "significantly"-family wording patches are held until then (P5R-B
§2).

**Addendum (same date, P5R-B §5-B3)**: the redundancy-threshold
sensitivity becomes the fifth family under cluster-robust re-inference.
Units and clustering, fixed before computation: per threshold tau, the
paired differences Delta rho (D - TAP) over the surviving
(target, seed) grid of the excl-redundant scope; seed remains the
independent block; the same M1 + M2 machinery applies per tau, reported
as a sensitivity curve with no per-tau claim of its own (the family
inherits the faithfulness family's reading).

**Addendum (2026-08-29, Chat ruling item 2; committed while zero
NP-MIMIC artifacts of ANY seed exist -- the 5-seed core pool is still
training and has written nothing)**: the NEW MIMIC NoPrior family
(P5R SS8) runs at the full 15 seeds -- the same list as every other
expanded family (1, 2, 3, 5, 8 + 13, 21, 34, 55, 89, 144, 233, 377,
610, 987) -- so no family remains at the n=5 design floor. Its readout
is withheld until all 15 matrices exist (no intermediate 5-seed look);
machinery unchanged. Scheduling per the same ruling: the A3
single-thread timing probes take the idle window first; the NP-MIMIC
expansion pool launches after A3 completes.
