# T4.5 statistics rules (operationalized pre-computation)

**Timing disclosure (prominent, non-negotiable)**: unlike the verdict
rules of T3.2/T4.3/T4.2, these rules are specified AFTER the grid data
existed and after descriptive aggregates (average ranks, medians) had
been seen, because T4.5 *is* the statistical treatment of that grid.
They are committed BEFORE any of the tests below were computed (zero
inferential artifacts at commit time — no Friedman statistic, no
post-hoc p, no TOST bound had been produced; attested in the commit
body). Every free parameter below is fixed by formula or convention,
not tuned against outcomes; the equivalence margin in particular is
anchored to seed-level noise, never to observed effects.

## Scope

Inputs: the completed grid (`results/P2_main_grid`, 2565 cells) via
`stats/aggregate_grid.load_runs`. Families of interest: per
(dataset × mechanism × rate × metric), methods compared across the five
seeds. Metrics: cont_NRMSE and cat_MacroF1 (primary pair, as in
Table 1); other recorded metrics may be reported descriptively but get
no inferential claim without appearing here.

## Tests (fixed)

1. **Omnibus**: Friedman test across the nine methods over seeds, per
   family (via `stats/omnibus.py`). Families with any missing method are
   refused, not imputed.
2. **Post-hoc**: pairwise Wilcoxon signed-rank of SNI vs each baseline
   within a family; **Holm correction over the 8 comparisons within
   that family** (family = the 8 SNI-vs-baseline pairs of one
   dataset × mechanism × rate × metric). Effect size: rank-biserial r
   (from signed ranks, version-proof, as `faithfulness._paired_effect`).
3. **CI**: seeded percentile bootstrap (10,000 resamples,
   rng seed 20260827) of the median paired difference.
4. **Equivalence (TOST)**, for parity claims only: two one-sided tests
   at alpha = 0.05 with margin
   **delta = 0.5 × median_within-family seed-SD of the metric across
   the nine methods** — a noise-anchored margin computed per family
   from dispersion alone, defined here before any TOST was run.
   A parity sentence in the paper must cite a TOST cell that passes at
   this margin; "not significantly different" alone licenses nothing
   (R1-5, R2-6).
5. **CD diagram** (`stats/cd_diagram.py`) at the pooled level Table 1
   uses, descriptive companion to the Friedman results.

## Outputs

`results/T4_stats/t45_stats.json` (+ CSV long forms): every test with
its family key, statistic, p, corrected p, effect size, CI, and — for
TOST — the margin value and both one-sided bounds. Prose and generators
cite fields of this artifact (`% src:`); no hand-copied statistic may
appear in the paper.

## Reading rules

- No new verdicts: T4.5 decorates existing tables with inferential
  honesty; it can weaken wording (a parity claim failing TOST is
  reported as inconclusive) but does not create claims.
- Any comparison against R0's published significance statements goes
  through `docs/comparison_registry.md`.

## Scale (pre-declared)

Pure aggregation over on-disk artifacts: minutes of compute, no
retraining, no GPU. Selftest (known-answer fixtures for the family
builder, Holm ordering, TOST margin formula and both TOST branches)
runs before the real data pass.
