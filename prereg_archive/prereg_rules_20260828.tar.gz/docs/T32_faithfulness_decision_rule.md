# T3.2 faithfulness — decision rule (committed before any result is computed)

Written per the P3 instruction (§3 T3.2) and the project discipline that verdict
rules are committed before the experiment that they judge (`41c522d`, `686702f`
precedents). The ablation harness may run after this commit; no A matrix, no
rho, and no verdict existed when this file was written.

## Ground truth

For each dataset (MIMIC, eICU), seed s in {1,2,3,5,8}, target f among the 12
masked (imputable, all continuous) features, source j among the 15 non-target
features:

    A[f,j] = mean over 5 permutations of NRMSE_f(permute j) − NRMSE_f(baseline)

where NRMSE_f is RMSE over f's masked cells against the complete table,
divided by the std of the true values on those cells (constant across
permutations, so the delta's ordering is the RMSE delta's ordering);
the permutation shuffles column j of the standardized model input across all
rows (marginal preserved, joint destroyed); the model is the run's own trained
per-feature CPFA in eval mode (dropout off, no_grad); the missingness pattern,
the pseudo-mask machinery and every training artifact stay untouched. In the
default SNI variant the model input carries no mask channel, so permuting
values cannot leak "j was intervened on" — the condition the instruction
required is satisfied by construction and is asserted (variant != SNI-M).

Permutation RNG: `np.random.default_rng(10_000*seed + 100*f_idx + 5*j_idx + r)`.

## Primary statistic

Per (dataset, seed, f): rho_M = Spearman(M[f, :], A[f, :]) over the 15
sources, for M in {SNI-D (retrained, bit-identity-checked against the stored
T2f.1 matrix), P, MissForest-importance, SHAP-on-MissForest,
Permutation-on-MissForest}. Secondary (reported, not binding): top-3/top-5
overlap with A's top-k, AUROC with A's top-3 as positive class.

Pooling: per dataset, the 60 paired values (12 targets × 5 seeds) of
Delta = rho_D − rho_P; two-sided paired Wilcoxon on the 60 pairs.

## Verdict rule (binding, in precedence order)

1. **Row 3 — D unfaithful** if median(rho_D) < 0.30 in either dataset.
   Reading: "attention is not explanation" holds for this method; the audit
   claim fails; **branch 2 re-enters**.
2. **Row 1 — D faithful, P is not** if, in **both** datasets,
   median(Delta) > 0 and Wilcoxon p < 0.05.
   Reading: the disclosure claim is positively validated; branch 1's
   concession stops at the recovery axis.
3. **Row 2 — D ≈ P** otherwise (including the mixed case where only one
   dataset clears rule 2 — resolved against ourselves by design).
   Reading: attention discloses nothing about the model's own behaviour
   beyond the prior; **branch 2 re-enters**.

Rows 2 and 3 are stop conditions (P3 §6.1): report immediately, do not
proceed to T3.3 without a ruling.

## Why Spearman, why these thresholds

Spearman matches every stability and agreement statistic used since T2f (the
claim under audit is about rank structure, and D rows are row-normalized so
only ranks are comparable across audit objects). 0.30 is the conventional
floor below which a rank correlation is not read as meaningful structure; it
is deliberately lenient toward D — failing a lenient floor is the strong
result. α = 0.05 two-sided, both-datasets conjunction, per the project's
practice of resolving design freedom against our own method.
