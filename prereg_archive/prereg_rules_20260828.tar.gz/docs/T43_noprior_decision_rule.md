# T4.3 NoPrior decision rule (pre-registered)

**Status: committed before any NoPrior run existed** (verified by listing:
zero NoPrior artifacts on either axis at commit time). Fixes how the
generality control is read; P4 §6.1 makes the narrow branch a stop-report.

## What is measured

NoPrior variant (alpha = 0: attention trained with no prior injection),
identical protocol otherwise.
- **Faithfulness axis (decisive)**: eICU x 5 seeds, T3.2's exact ablation
  caliber; primary statistic = row-level Spearman rho(row, A-row), median
  over 60 (target, seed) pairs; paired Delta(NoPrior-D minus TAP).
- **Recovery axis**: the pilot's 15 synthetic cells, pilot scorer and common
  rows; primary = AUROC; paired Delta(NoPrior-D minus TAP) over 15 cells.

## Verdict (three tiers, precedence top-down; ambiguity resolves toward
## narrowing, because overclaiming scope is the risk and narrowing merely
## weakens us)

1. **DIFFERENT-TYPE (mandatory narrow + stop-report, P4 §6.1)** if on EITHER
   axis NoPrior-D significantly beats TAP: median Delta > 0 AND two-sided
   Wilcoxon p < 0.05.
2. **BORDERLINE (report as inconclusive-toward-narrowing; first author
   decides wording)** if median Delta > 0 on either axis without
   significance.
3. **SAME-TYPE (C3 stands at artifact-type level)** only if median
   Delta <= 0 on BOTH axes.

Effect sizes and CIs accompany every tier (same ruler); absolute levels
reported alongside (a NoPrior-D that is unfaithful in absolute terms,
median rho < the 0.30 floor, is stated as such whichever tier applies).
||D_NoPrior - D|| recorded descriptively; it gates nothing.

## Fixed wording consequences

- SAME-TYPE: "the conclusion concerns attention-derived reliance matrices
  as a practice, not the prior-regularised implementation."
- DIFFERENT-TYPE / BORDERLINE: C3's scope narrows to "prior-regularised
  attention implementations" in Introduction, §5.1 and Conclusions; the
  narrowing is stated as a scope correction, not a retreat.
