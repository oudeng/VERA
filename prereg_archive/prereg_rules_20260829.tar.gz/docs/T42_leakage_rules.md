# T4.2 leakage-detection rules (pre-registered)

**Status: committed before any T4.2 run existed** (zero artifacts at commit
time). Spec unchanged from P3 §3 / P4 ruling 2; this file fixes calibration,
detection criterion, and reporting before any injection is trained.

## Design (unchanged, restated as binding)

Five proxy classes -- exact duplicate; noisy duplicates rho ~ 0.95 / 0.80 /
0.60; INTERACTION-type (marginally ~independent of target, predictive only
jointly with another column); consequence field; decoy (marginally
correlated, no incremental information) -- x 3 seeds x 2 datasets
(MIMIC, eICU). Nulls: permutation null (injected column shuffled, per
condition) and >= 20 random-proxy calibration runs. Objects: the six of
Table 4 (Permutation-on-SNI included -- leakage detection is NOT circular
for it: the truth is the injection, not the ablation).

## Detection criterion (fixed)

For each object and each injected condition: the proxy column's score in
the affected target row(s). "Detected at FPR alpha" iff that score exceeds
the empirical (1 - alpha) quantile of the random-proxy calibration
distribution for the same object, position caliber and dataset.
**alpha = 0.05, fixed here.** Rank trajectories across proxy strengths
(0.60 / 0.80 / 0.95 / exact) are reported as curves.

## Reporting (fixed regardless of direction)

- Detection counts per (object x class) out of 6 injections, with Wilson
  95% intervals; classes NEVER pooled into one number.
- The interaction-proxy class gets its own subsection whichever way it
  falls (P4 ruling 2). Pre-fixed reading: TAP is structurally blind here
  (a marginal-association prior cannot rank a marginally-independent
  column highly); the question is whether any behavioural readout, D
  included, sees what TAP cannot.
- **Signal threshold for the P4 §6.4 stop-report ("D wins clearly on
  interaction proxies")**: D detects >= 3 of 6 interaction injections at
  the calibrated FPR while TAP detects <= 1. Report exact counts either
  way; the old P3 condition (TAP >= D on interaction) remains a reporting
  requirement, not a branch trigger (P4 ruling 2).
- Decoy class is scored as a FALSE-POSITIVE check: an object that ranks
  the decoy above the calibration quantile is reported as flagging a
  non-leak, with counts.

## Scale gate (unchanged)

Launch only after the grid completes and after the scale/machine-hours
estimate is reported (P4 §5 sequencing).

## Addendum 2026-08-24 — launch condition amended (P4K §1)

**What changes**: the launch condition above ("after the grid completes")
becomes "**after >= 10 of the 12 CPU grid shards have exited**". Nothing
else changes: every verdict clause of this file — the five proxy classes,
the FPR = 0.05 matched-calibration criterion, the permutation null, the
>= 20 random-proxy calibration runs, per-class reporting, the interaction
stop threshold and the decoy false-positive check — stands word for word.

**Why the amendment is admissible (P4K §1.1 determination)**: the gate's
written reason is the section title itself — a *scale* gate, "after the
grid completes and after the scale/machine-hours estimate is reported
(P4 §5 sequencing)" — i.e. scheduling and machine-hours only. T4.2
consumes no grid product: its hosts are the probe-subset retrains
(T3.2 pipeline) and its objects the six of Table 4 (five-way artifacts),
all independent of `results/P2_main_grid`. Had the gate encoded a data
dependency, this amendment would be void per P4K §1.1.

**Guardrails bound with the amendment** (P4K §1.3–1.5): T4.2 worker count
+ alive grid shards <= 12; nice 10; BLAS=2 asserted as everywhere; the
T4.2 run window (start/end) is logged to JOB_BOARD and the
`--fit-from-grid` cost generator must be able to footnote which grid
cells' wall clock overlapped that window (transparency note, no number
changed); runner + analyzer pass a known-answer fixture selftest before
touching real data; scale is recomputed from authoritative sources on
launch day and re-reported first if > 20% above ~124 host retrains /
~17 machine-hours; stop conditions per P4K §1.5.

*Erratum 2026-08-24 00:45 (unit transcription, caught by the plan stage's
own gate check before any run)*: "~17 machine-hours" above conflated two
calibers. The pre-registered scale is **~124 host retrains ≈ 159
machine-hours** at the P4_T41_report per-run figures (MIMIC 5500 s / eICU
3720 s), i.e. **~16–17 wall-clock hours on ~10 parallel workers**. The
20% re-report trigger compares like with like: retrain count against 124
and machine-hours against 159. No other clause is affected.

**Approval**: first author, 2026-08-24, by transfer of
`Instruments/P4K_T42_gate_amendment_and_T43_rule_check.md` (its §0.1).
No adjudications.md / test_adjudications.py assertion corresponds to the
old condition (checked 2026-08-24; grep in receipt), so none is updated.

## Addendum #2, 2026-08-25 — launch condition amended to the envelope itself (P4M-era adjudication, transferred 2026-08-25)

**What changes**: the launch condition of Addendum 2026-08-24 ("after
>= 10 of the 12 CPU grid shards have exited") becomes: **launch when
12 − alive_shards >= 9** (i.e. at most 3 shards alive), with
**workers = min(12 − alive_shards, 10)**. Rationale: the first
amendment's wording over-specified the *count* where the gate's stated
reason was always the §1.3 resource envelope (workers + alive <= 12);
the exit cascade left three stragglers each holding one ~60 h
REAL_PATTERN cell, which would have idled the envelope for ~1.5 days
without protecting anything. Every verdict clause remains word for
word untouched; the dual-baseline sentinel (archived + self-calibrated,
P4K-A/B), worker window files, the cost-table overlap footnote, and the
in-code envelope refusal (alive + workers > 12 refuses to run) all ride
along unchanged.

**Approval**: first author, 2026-08-25, by transfer of the Chat
adjudication; committed before launch. No adjudications.md /
test_adjudications.py assertion corresponds to the launch condition
(re-checked at commit time; grep count 0), so none is updated.


---

**Addendum (2026-08-29): the information-symmetry clause.**

*This addendum records a rule gap and closes it. It is a correction of the
rules, not a re-run chosen for its result: it is written before the
recomputation it governs has produced a number, and the corrected readouts
are reported whichever direction they move.*

The rules of this project fixed, per axis, what would be compared, against
what reference, and under what decision rule. They did not fix that **the
objects compared under one reference must have had access to the same
information**. On 2026-08-29 an information-symmetry census
(`experiments/information_symmetry_census.py`,
`results/T6_symmetry/information_symmetry_census.json`) found that they had
not: on the recovery, leakage and stability axes, `Permutation-on-SNI`
computes its error signal against the values withheld from the imputer
(`experiments/t4f_perm_on_sni.py:91,106`;
`experiments/t42_leakage.py:413` — `truth = complete[f][miss]`), while every
object it is compared with derives its values from the masked table or from
an imputer's own completion — including its same-type competitor
`Permutation-on-MissForest`, whose `permutation_importance` is scored against
MissForest's own completed values (`experiments/pilot_r21.py:263,281`).

**The clause, applying from this date to every axis:** the objects compared
under one reference must have had access to the same information; where they
have not, the privileged object is aligned **downward** to the common
denominator its competitors already use — never the competitors upward — and
the asymmetry is disclosed in the manuscript whether or not it is corrected.
A real auditor does not hold the withheld values; not holding them is the
fair common denominator.

**Superseded readouts are archived, never overwritten**
(`results/T6_symmetry/superseded_20260829_oracle_error_signal/`), and the old
and new numbers are reported side by side with their difference.

**Scope of this addendum for the leakage axis.** The privileged object here is
`Permutation-on-SNI`; `SNI-D`, `TAP`, and the three MissForest readouts are
not privileged. The asymmetry runs in the direction that favours the
privileged object's detection counts, so the axis's `D` 0/6 versus same-host
probe 6/6 contrast may not be stated as a comparison between objects with
equal information. That qualification is added to the manuscript immediately,
ahead of any recomputation.

**The recomputation decision for this axis was fixed on 2026-08-29, before the
inputs to it existed.** The 138 archived leakage runs kept no host weights, so
a rerun costs a median 5,724 s per run — about 219 hours single-stream, 67
hours wall at the original three-way parallelism. The cheaper recovery-axis
recomputation (same probe, same correction, hosts also unarchived but only 15
of them) settles the same question about the probe's capability without
privileged information. Therefore:

- **if, on the recovery axis, `Permutation-on-SNI` still beats the strongest
  MissForest-hosted readout without the oracle** ⇒ the leakage axis is **not**
  recomputed and the disclosure above stands as the final treatment, on the
  stated ground that the probe's capability under non-privileged information
  is directly established on the recovery axis and the leakage direction does
  not reverse because of the asymmetry;
- **if it no longer beats it** ⇒ the 6/6 loses its "the probe is simply
  strong" support, and the leakage axis **is** recomputed at the 67-hour
  cost, with the schedule reconfirmed against the calendar remaining before
  the 2026-09-10 deadline.

No other branch is admissible, and this one is not reopened after the recovery
numbers are seen.
