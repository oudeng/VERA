# T6.1 Information symmetry — census rules, recompute rules, and the
# pre-adjudication

**Layer**: audit + defect-correction rule, committed **before the census
exists, before the recompute exists, and before any corrected number has been
seen**. Issued on the first author's adjudication of 2026-08-29 in response to
`reports/P5R_L_S0b_second_finding.md`.

**Zero-artifact attestation (repository state at the commit introducing this
file)**: `results/T6_symmetry/` does not exist;
`experiments/information_symmetry_census.py` does not exist; no no-oracle
ablation matrix exists anywhere in the tree; no recovery or leakage readout
has been recomputed; the pre-adjudication in §5 is written before any of its
inputs can be known.

---

## 1. The rule gap this closes

`docs/T4F_presentation_rule.md` admitted `Permutation-on-SNI` to the recovery
and stability tables on the ground that *"truth is the external synthetic DAG
— not circular"*. That rule covers **circularity**. It does not cover
**information symmetry**: whether the objects being compared had access to the
same information.

They did not. `_ablate` (`experiments/t4f_perm_on_sni.py:91,106`) and its twin
in `experiments/t42_leakage.py:413` compute their error signal against
`complete[f][miss]` — the cells withheld from the imputer — while every object
they are compared with derives its values from the masked table or from an
imputer's own completion.

**From this commit onward, every axis comparison carries a symmetry clause**:
the objects compared under one reference must have had access to the same
information, and any exception is declared and disclosed in the manuscript.

## 2. The census (first author's precondition 1)

`experiments/information_symmetry_census.py` enumerates, for every axis on
which two or more objects are compared under one reference:

- the reference the comparison is made against;
- every object compared;
- for each object, the table its values are derived from, and **whether any
  withheld cell enters its computation** — determined from the source, with
  the file:line quoted;
- the verdict **SYMMETRIC** / **ASYMMETRIC**, and if asymmetric, which objects
  hold information the others lack.

Axes in scope, at minimum:

1. **recovery** — the six objects scored against the synthetic DAG `G`;
2. **leakage** — the six objects scored against the injected proxies;
3. **stability** — the objects scored on cross-seed agreement, including the
   `Permutation-on-SNI` row and the **host band** that `t43_verdict.py` reads
   from `perm_on_sni_real_stability.csv`;
4. **faithfulness** — the reference matrix `A` itself. `D` and `TAP` are
   scored against one ruler, so there is no inter-object asymmetry there; what
   the census must record is `A`'s **semantics**: it is host behaviour measured
   *with privileged information*, not host behaviour simpliciter, and the
   manuscript must say so in those terms;
5. **cost** — timings, no error signal; recorded for completeness.

**The census output determines the recompute list. The recompute runs once,
over the whole list, not in batches.**

## 3. The recompute (first author's precondition 3: align downward)

Where the census finds an asymmetry, the correction is **always** to bring the
privileged object **down** to the common denominator its competitors already
use: an error signal that reads **no withheld cell**. The competitors are
never raised to read truth. A real auditor does not have the withheld values;
the fair common denominator is not having them.

Concretely, for `_ablate` and its leakage twin: the error target becomes the
imputer's own completed values on the same cells — `X_final[f][miss]` — which
is exactly the signal `Permutation-on-MissForest` already uses
(`experiments/pilot_r21.py:263,281`, `y = numeric[target]` from MissForest's
own completion). Nothing else in the ablation changes: the same permutation
count, the same RNG streams, the same standardisation, the same rows.

## 4. The recompute (first author's precondition 2: cold-load before retraining)

Cold-loading was checked before this rule was written, and the result is
recorded here because it constrains what follows:

- **Real-table hosts: archived.** `results/T3_faithfulness/models_*.pt` and
  `Xfinal_*.csv` exist for all 60 real-table runs, and probe 2 already
  cold-loads them. Any real-table recompute is minutes, with **no new training
  randomness**.
- **Synthetic hosts: NOT archived.** `results/T4_perm_on_sni/` holds only
  `D_RETR_*.csv`, `PERM_*.csv` and `meta_*.json`; no weights, no `Xfinal`.
  A synthetic recompute therefore requires retraining, ~3,200 s per cell
  (`meta_*.json`), 15 cells.
- The archived synthetic hosts were **already** not bitwise reproducible: the
  recorded `D_max_abs_diff` against the pilot store is 0.0090–0.0614, not 0.
  A fresh retrain is therefore a different draw either way.

**Consequence, fixed here:** where retraining is unavoidable, the shipped
(oracle) and corrected (no-oracle) matrices are computed **on the same freshly
retrained host**, so the contrast is within-host and the host draw cancels.
The freshly computed oracle matrix is additionally compared with the archived
one, and that distance is reported. The recompute is not permitted to change
any other number by silently substituting a new host: any archived quantity
that moves is reported as moved, with both values.

## 5. The pre-adjudication (fixed before the numbers exist)

The first author fixed the following on 2026-08-29, before the recompute. It
is executed mechanically; no post-hoc reading of it is admissible.

- **If, after the recompute, `Permutation-on-SNI` still beats the strongest
  MissForest-hosted readout** ⇒ the third leg of the §5.1 mechanism argument
  ("the host's function does encode real structure; what fails is the
  artifact") **stands**. The numbers are updated and the disclosure of §6 is
  added anyway.
- **If it no longer beats it** ⇒ the third leg is **removed**: "the window
  exists" and "what fails is the artifact, not the host's function" are
  withdrawn, or narrowed to what the evidence then supports (the fifth
  internal review's P0-6 already required that sentence to be narrowed);
  §5.1 is rewritten to the narrow version, and Fig. 3's recovery cell and
  Table 4 are synchronised with it.
- **In both cases**: the superseded readouts are archived and never silently
  overwritten; the old and new numbers and their difference are reported
  together; `docs/T4F_presentation_rule.md` receives a dated addendum stating
  the rule gap (it covered circularity, not information symmetry) and adding
  the symmetry clause, which from then on applies to every axis.

The comparison that decides this is stated now so it cannot be chosen later:
**the recovery-axis AUROC of `Permutation-on-SNI` against the strongest
MissForest-hosted readout, per regime and pooled, under the estimand the
recovery axis already uses** (mean of seed-level medians, exact enumeration
under seed-block sign-exchangeability, seed-only bootstrap CI).

## 6. Disclosure (first author's option 乙, to be done regardless of direction)

Whatever the recompute shows:

- Table 4's note and §5.1 state that this object's error signal reads cells
  withheld from the imputer while its competitors' do not — and, after the
  correction, that it no longer does;
- the faithfulness reference `A` is described as host behaviour measured
  **against the withheld values**, so a reader knows what the ruler is;
- the stability table's `Permutation-on-SNI` row and the host band derived
  from it carry the same note, in the weaker form that applies there (the
  cross-seed statistic measures the matrix's stability, not its accuracy, but
  the matrix is oracle-derived and its competitors' are not);
- `docs/T4F_presentation_rule.md` gets the dated addendum of §5.

## 7. Outputs

- `results/T6_symmetry/information_symmetry_census.json` — §2;
- `results/T6_symmetry/no_oracle_recompute.json` — old vs new per object per
  regime, the archived-vs-fresh oracle distance, and the §5 decision as
  evaluated by code;
- `results/T6_symmetry/superseded_<date>_oracle_error_signal/` — the
  superseded readouts, verbatim, with a README saying why they are kept;
- a dated addendum in `docs/T4F_presentation_rule.md`.

## 8. What this cannot establish

It establishes what the code computes and what the archived artifacts contain.
Where a host must be retrained because its weights were not archived, the
recomputed numbers come from a different draw of that host than the published
ones; the within-host contrast is what carries the conclusion, and the
archived-vs-fresh distance is reported so a reader can see how much the draw
moved.

---

## Addendum (2026-08-29b): the stability band, and the chain it feeds

*Written before the no-oracle band has been computed. `results/T6_symmetry/`
holds the ten `A_noOracle_*.csv` matrices and `stability_noOracle_cells.csv`
(the per-host oracle-vs-no-oracle agreement) and nothing else; no cross-seed
band has been formed from them, no `T_stab` has been recomputed, and no
mechanism verdict has been re-evaluated.*

Two of the four legs of the §5.1 mechanism argument rest on this object:

- **(i) over-stability** — `\Dm{}` at 0.891 against the *host band* 0.528,
  where that band **is** `Permutation-on-SNI`'s cross-seed stability;
- **(iii) the window** — 0.920 vs 0.912 on recovery, under recomputation.

Legs (ii) (`rho ~ 0.80` with TAP) and (iv) (the `lambda <= ln 2` invariant) do
not involve it.

### The band

The no-oracle band is computed by `t4f_perm_on_sni.stage_real`'s algorithm
verbatim — pairwise Spearman over the entries selected by the first seed's
`notna` mask, all ten pairs per table — applied to the no-oracle matrices.
Nothing else changes.

**Pre-adjudication, fixed here:**

- **the new band remains materially below `\Dm{}`'s 0.891** ⇒ leg (i) stands;
  the numbers are updated and the disclosure is added anyway;
- **the new band is comparable to or above 0.891** ⇒ leg (i) is withdrawn, or
  narrowed to what the evidence then supports, and §5.1, Tables 4 and 5 and
  Fig. 3's stability cell are synchronised with it.

### The chain it feeds

The T4.3 O1 gate takes the band as an input:
`T_stab = host + 0.5 * (D_prior - host)` (`experiments/t43_verdict.py:290`).
`O1` and the mechanism verdict are therefore recomputed with the corrected
band. **If the verdict category changes (MECH-MIXED to anything else), T4.3's
own rule applies: report and stop; the mechanism section is not rewritten
here.** Old and new values are reported side by side and the old ones are
archived, never overwritten.

### Scope limit

The band is computed from the real-table matrices, whose hosts are archived,
so this is a cold load with no new training randomness. It says nothing about
the recovery axis, which is a separate recomputation.

## Addendum (2026-08-29c): the recovery readout, and leg (iii)

*Written before the no-oracle recovery readout has been scored.
`results/T6_symmetry/` holds the thirty recomputed permutation matrices
(`PERM_oracle_*` and `PERM_noOracle_*`, fifteen cells each), their fifteen
`meta_noOracle_*.json` timing records, and `no_oracle_recompute_recovery.json`
-- which contains ONLY per-cell wall-clock and the fresh-oracle-versus-archived
maximum absolute difference. No AUROC has been computed from any of them, no
object has been ranked, and no comparison against the externally hosted
readouts exists. The scoring script named below does not exist yet either.*

### What leg (iii) claims now

> the same-host behavioural probe recovers no worse than the strongest
> externally hosted readout (0.920 vs. 0.912; Table 3)

0.920 is `Permutation-on-SNI`'s mean AUROC over the fifteen synthetic cells and
0.912 is the best mean AUROC among the three externally hosted readouts
(`MissForest-importance`, `SHAP-on-MissForest`, `Permutation-on-MissForest`).
The sentence already carries the asymmetry disclosure; the recompute is what
removes the asymmetry rather than disclosing it.

### How the no-oracle readout is computed

`t4f_perm_on_sni.stage_score`'s algorithm verbatim -- the same `load_cell`,
the same `measured_rows` intersection over all objects in the cell, the same
`score()` -- with one substitution: the `Permutation-on-SNI` matrix is read
from `PERM_noOracle_<regime>_s<seed>.csv` instead of the archived
`PERM_<regime>_s<seed>.csv`. Nothing else changes.

Three objects are scored side by side so the recompute's own two effects stay
separable:

1. **archived** -- the archived matrices, i.e. the number in the paper today;
2. **refit + oracle** -- the freshly retrained host, error signal still scored
   against the withheld values. Isolates what retraining alone moved;
3. **refit + no oracle** -- the freshly retrained host, error signal scored
   against the host's own completed table. This is the symmetric object.

The comparison is run twice and both are reported: once with each variant
scored on its own `common` row set (exactly as the archived recipe would have
scored it), and once with all variants restricted to the intersection of their
row sets (so the head-to-head uses identical rows). If the two disagree in
direction, the intersection version governs and the disagreement is reported.

### Pre-adjudication, fixed here (the first author's, restated mechanically)

- **`Permutation-on-SNI` (refit + no oracle) mean AUROC still at least the
  strongest externally hosted readout's** ⇒ leg (iii) stands; the numbers are
  updated and the asymmetry sentence is rewritten from a disclosure of
  unequal information into a statement that the comparison is now equal;
- **it no longer does** ⇒ leg (iii) is withdrawn or narrowed to what the
  numbers then support, and §5.1, Table 3 and Fig. 3's recovery cell are
  synchronised with it.

Either way the archived readings are kept beside the new ones and are not
overwritten, and the direction is reported whichever way it falls.

### What this cannot establish

Fifteen cells at five seeds is the same floor the recovery axis already
declares: no recovery comparison reaches significance at five seeds, and this
recompute does not change that. The readout is a mean over cells, reported as
such, and the pre-adjudication is stated as a comparison of that mean -- not as
a significance test.
